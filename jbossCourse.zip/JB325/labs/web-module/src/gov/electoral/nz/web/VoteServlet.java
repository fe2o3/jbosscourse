package gov.electoral.nz.web;

import gov.electoral.nz.Ballot;
import gov.electoral.nz.OfficeBallot;
import gov.electoral.nz.ejb.VotingBooth;
import gov.electoral.nz.ejb.VotingBoothBean;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Voting Booth Servlet Enters a vote into the EJB
 * 
 */
public class VoteServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private static Log log = LogFactory.getLog(VoteServlet.class);

	private VotingBooth booth;

	private boolean debug = false;
	private static final String SESSION_ID = "sessionid";

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		String command = (String) request.getParameter("command");

		try {
			InitialContext ctx = new InitialContext();
			booth = (VotingBooth) ctx.lookup(VotingBoothBean.JNDI_NAME);
			log.debug("Set up the Initial Context");
		} catch (NamingException e) {
			log.error("Lookup of EJB failed:", e);
		}

		String sid = (String) request.getSession().getAttribute(SESSION_ID);
		//int sessionid = (sid != null) ? Integer.valueOf(sid) : 0;

		String position = (String) request.getParameter("position");
		int posint = (position != null) ? Integer.valueOf(position) : 0;
		String party = (String) request.getParameter("party");
		int partyint = (party != null) ? Integer.valueOf(party) : 0;

		String message = "Please login.";
		String partyName = null;
		String positionName = null;
		if (command != null && command.equals("Vote")) {
			partyName = booth.getParty(partyint);
			request.setAttribute("partyName", partyName);
			positionName = booth.getPosition(posint);
			request.setAttribute("positionName", positionName);
			Ballot ballot = booth.getResults(sid);
			List<String> parties = new ArrayList<String>();
			parties.add(partyName);
			OfficeBallot ob = new OfficeBallot(position, parties);
			ballot.officeList.add(ob);
			booth.vote(sid, ballot);
			message = "Thank you for voting.";
			log.debug("Vote was cast.");
		}
		
		if (command != null && command.equals("Log In")) {
			String username = (String) request.getParameter("username");
			String password = (String) request.getParameter("password");
			sid = booth.login(username);
			request.getSession().setAttribute(SESSION_ID, sid);
			request.setAttribute(SESSION_ID, sid);
			message = "Record your vote.";
			log.debug("Session id=" + sid);
		}

		request.setAttribute("messages", message);

		if (debug)
			request.setAttribute("debugtext", debugHTML(request));

		getServletConfig().getServletContext()
				.getRequestDispatcher("/vote.jsp").forward(request, response);

		response.setHeader("Cache-Control", "no-cache");
		response.setContentType("text/xml");

		out.flush();
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	private String debugHTML(HttpServletRequest request) {
		StringBuffer buff = new StringBuffer();
		buff.append("<table border='1'>");
		buff.append("<tr><td colspan='2' align='center'>DEBUG</td></tr>");
		buff.append("<tr><th>Parameter</th><th>Value</th></tr>");
		Enumeration en = request.getParameterNames();
		while (en.hasMoreElements()) {
			String name = (String) en.nextElement();
			String value = request.getParameter(name);
			buff.append("<tr><td>").append(name).append("</td><td>").append(
					value).append("</td></tr>");
		}
		buff.append("<tr><th colspan='2'>JMX Cache</th></tr>");
		/*
		 * try { buff.append("<tr><td colspan='2'>" + counter.getCurrentCount()
		 * + "</td></tr>"); } catch (RemoteException e) { log.error("", e); }
		 */
		buff.append("</table>");
		buff.append("<br/>");
		return buff.toString();
	}

}
