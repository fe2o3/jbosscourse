package gov.dot.us.web;

import gov.dot.us.aop.PropagationManager;
import gov.dot.us.ejb.StatelessAction;
import gov.dot.us.service.WebCache;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * Servlet for accessing JBoss Cache from JBoss AS server
 * 
 * @author dnorwood@redhat.com
 * 
 */
public class CacheServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	private static Log log = LogFactory.getLog(CacheServlet.class);

	private StatelessAction action;
	private boolean debug = true;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		action = (StatelessAction) BeanProvider.get(BeanProvider.STATELESS_ACTION);
		PropagationManager pm = action.getManager();
		WebCache wc = action.getWebCache();

		Map<Long, String> components = new HashMap<Long, String>();
		components.put(1001L, "Power Supply");
		components.put(1002L, "Sensor Unit");
		components.put(1003L, "Battery Charger");

		String country = (String) request.getParameter("country");
		String city = (String) request.getParameter("city");
		String sensor = (String) request.getParameter("sensor");
		String id = (String) request.getParameter("id");
		String state = (String) request.getParameter("state");
		String fail = (String) request.getParameter("fail");
		String severity = (String) request.getParameter("severity");
		String command = (String) request.getParameter("save");

		String countries = (String) request.getParameter("countries");
		if (countries != null && !countries.isEmpty())
			country = wc.getOption(WebCache.COUNTRY_SELECTOR, countries);
		String cities = (String) request.getParameter("cities");
		if (cities != null && !cities.isEmpty())
			city = wc.getOption(WebCache.CITY_SELECTOR, cities);

		//if (command != null && command.startsWith("Submit")) {
		String pm_before = pm.printNodes();
		if (command != null) {
			if (!pm.hasNodes())
				pm.setRootNode(country);
			pm.addNode(country, city);
			pm.addNode(country + "." + city, sensor);
			Long lid = Long.valueOf(id);
			pm.addStateItem(country + "." + city + "." + sensor, lid,
					components.get(lid), Boolean.valueOf(fail), Integer.valueOf(severity));
			wc.addOption(WebCache.COUNTRY_SELECTOR, country);
			wc.addOption(WebCache.CITY_SELECTOR, city);
			action.snapShot(pm, wc);
		}

		StringBuffer buff = new StringBuffer();
		for (Long key : components.keySet()) {
			buff.append("<option value='").append(key.intValue()).append("'>").append(
					components.get(key)).append("</option>");
		}
		String component_list = buff.toString();

		String sensor_list = "<option value='wind'>Wind Sensor</option><option value='rain'>Rain Sensor</option>";
		String severity_list = "<option value='0'>None</option><option value='1'>Low</option>"
				+ "<option value='2'>Medium</option><option value='3'>Moderate</option><option value='4'>High</option>";

		// StringBuffer buff = new StringBuffer();
		// for (Node node:nodes) {
		// buff.append("<option value='" + node.getNodeFDN() +
		// "'>"+node.getNodeFDN()+"</option>");
		// }
		// String nodelist = buff.toString();

		countries = wc.getSelector(WebCache.COUNTRY_SELECTOR);
		cities = wc.getSelector(WebCache.CITY_SELECTOR);

		out.println("<html>");
		out.println("<head>");
		out.println("<title>lab-cache: POJO Cache</title>");
		out.println("<link rel='StyleSheet' href='lab.css' type='text/css' />");
		out.println("</head>");
		out.println("<body>");
		out.println("<h1>POJO Cache</h1>");

		out.println("<table width='90%' class='big-table'>");
		out.println("<tr><th>Cache Before</th></tr>");
		try {
			/*
			 * Pass Util instance to EJB
			 */
			out.println("<tr><td>");
			if (pm.hasNodes()) {
				out.println("<table cellpadding='8'>");
				out.println("<tr><td>" + pm_before + "</td></tr>");
				out.println("</table>");
			}
			out.println("</td></tr>");
		} catch (Throwable t) {
			out.println("<PRE>");
			t.printStackTrace(out);
			out.println("</PRE>");
		}
		out.println("<tr><th>Cache Now</th></tr>");
		try {
			/*
			 * Pass Util instance to EJB
			 */
			out.println("<tr><td>");
			if (pm.hasNodes()) {
				out.println("<table cellpadding='8'>");
				out.println("<tr><td>" + pm.printNodes() + "</td></tr>");
				out.println("</table>");
			}
			out.println("</td></tr>");
		} catch (Throwable t) {
			out.println("<PRE>");
			t.printStackTrace(out);
			out.println("</PRE>");
		}
		String[] messages = pm.getMessages();
		if (messages.length > 0) {
			out.println("<tr><td>");
			for (String msg:messages)
				out.println(msg + "<br/>");
			out.println("</tr></td>");
		}
		out.println("</table>");

		out.println("<form id='mainform' action='#'>");
		out.println("<fieldset>");
		out.println("<legend>State Changer</legend>");
		out.println("<label for='countries'>Country:</label>");
		out.println("<select name='countries' class='standard'>" + countries + "</select>&nbsp;");
		out.println("<input type='text' name='country' size='30' class='standard'/>");
		out.println("</br>");
		out.println("<label for='cities'>City:</label>");
		out.println("<select name='cities' class='standard'>" + cities + "</select>&nbsp;");
		out.println("<input type='text' name='city' size='30' class='standard'/>");
		out.println("</br>");
		out.println("<label for='sensor'>Sensor:</label><select name='sensor' class='standard'>" + sensor_list
				+ "</select><br/>");
		out.println("<label for='id'>Component:</label><select name='id' class='standard'>" + component_list
				+ "</select><br/>");
		out.println("<label for='state'>State</label>");
		out.println("<input type='radio' name='state' value='1'/> Physical");
		out.println("<input type='radio' name='state' value='2'/> Summary<br/>");
		out.println("<label for='fail'>Result</label>");
		out.println("<input type='radio' name='fail' value='1'/> Failed");
		out.println("<input type='radio' name='fail' value='0'/> OK<br/>");
		out.println("<label for='severity'>Severity</label>");
		out.println("<select name='severity' class='standard'>" + severity_list + "</select><br/>");
		out.println("<input type='button' value='Refresh' style='float:right;'/>");
		out.println("<input type='submit' id='save' name='save' value='Submit' style='float:right;'/>");
		out.println("</fieldset>");
		out.println("</form>");
		out.println("</body>");
		if (debug)
			out.println(debugHTML(request));
		out.flush();
		out.close();
	}
	
	private String debugHTML(HttpServletRequest request) {
		StringBuffer buff = new StringBuffer();
		buff.append("<table border='1'>");
		buff.append("<tr><td colspan='2' align='center'>DEBUG</td></tr>");
		buff.append("<tr><th>Parameter</th><th>Value</th></tr>");
		Enumeration e = request.getParameterNames();
		while (e.hasMoreElements()) {
			String name = (String)e.nextElement();
			String value = request.getParameter(name);
			buff.append("<tr><td>").append(name).append("</td><td>").append(value).append("</td></tr>");
		}
		buff.append("<tr><th colspan='2'>JMX Cache</th></tr>");
		buff.append("<tr><td colspan='2'>" + action.printCache() + "</td></tr>");
		buff.append("</table>");
		buff.append("<br/>");
		return buff.toString();
	}


}
