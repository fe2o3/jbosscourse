package gov.dot.us.web;

import gov.dot.us.ejb.StatelessAction;
import gov.dot.us.ejb.StatelessActionBean;

import java.util.HashMap;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.cache.CacheException;

/**
 * Singleton EJB JNDI service locator
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 * 
 * @see <a href='http://java.sun.com/blueprints/corej2eepatterns/Patterns/ServiceLocator.html'>ServiceLocator</a> pattern
 */
public class BeanProvider {

	/** EJB cache */
	private static Map<Integer, Object> cache;

	private static Log log = LogFactory.getLog(BeanProvider.class);
	
	public static final int STATELESS_ACTION = 1;

	private static BeanProvider instance;

	/**
	 * Singleton has a private constructor. Add any additional EJB's as needed.
	 */
	private BeanProvider() {
		cache = new HashMap<Integer, Object>();
		StatelessAction bean = null;
		try {
			Context ic = new InitialContext();
			bean = (StatelessAction) ic.lookup(StatelessActionBean.JNDI_NAME);
			cache.put(STATELESS_ACTION, bean);
		} catch (Exception e) {
			log.error("Error finding EJB in JNDI:", e);
		}
	}

	public static BeanProvider instance() throws Exception {
		if (instance == null)
			instance = new BeanProvider();
		return instance;
	}

	/**
	 * Get an EJB JNDI reference from the cache
	 * @param which
	 * @return
	 */
	public static Object get(int which) {
		try {
			return instance().cache.get(which);
		} catch (CacheException e) {
			log.error("Cache error:", e);
		} catch (Exception e) {
			log.error("Error:", e);
		}
		return null;
	}

}
