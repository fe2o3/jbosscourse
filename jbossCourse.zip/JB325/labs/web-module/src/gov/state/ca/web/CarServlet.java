package gov.state.ca.web;

import gov.state.ca.ejb.CarCounter;
import gov.state.ca.ejb.CarCounterBean;

import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.util.Enumeration;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * Servlet for accessing a simple counter EJB.
 * For demonstration of cluster fail-over.
 * Goes with JB325 lab9.
 * 
 * @author dnorwood@redhat.com
 * 
 */
public class CarServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	private static Log log = LogFactory.getLog(CarServlet.class);

	private CarCounter counter;

	private boolean debug = false;
	
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

	public void doPost(HttpServletRequest request, HttpServletResponse response)
		throws IOException, ServletException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		PrintWriter out = response.getWriter();

		String command = (String) request.getParameter("save");
		String refresh = (String) request.getParameter("refresh");
		int refreshint = (refresh != null) ? Integer.valueOf(refresh):1000;

		String speed = (String) request.getParameter("speed");
		int speedint = (speed != null && !speed.isEmpty()) ? Integer.valueOf(speed):55;
		int carsPerCount = Math.abs(speedint/5);

		try {
			InitialContext ctx = new InitialContext();
			counter = (CarCounter) ctx.lookup(CarCounterBean.JNDI_NAME);
			
		} catch (NamingException e) {
			log.error("Lookup of EJB failed:", e);
		}

		String query = (String) request.getParameter("operation");
		String reply = null;
		if (query.equals("getCount")) {
			reply = String.valueOf(counter.addCounter(carsPerCount));
		}
		if (refresh != null && !refresh.isEmpty()) {
			request.setAttribute("refresh", refreshint);
		}
		if (speed != null  && speedint != counter.getSpeed()) {
			counter.setSpeed(speedint);
			log.info("Speed was changed to " + speed);
		}

		out.print(reply);
        response.setHeader("Cache-Control", "no-cache");
        response.setContentType("text/xml");

		if (debug)
			request.setAttribute("debugtext",debugHTML(request));
		out.flush();
		out.close();
	}

	private String debugHTML(HttpServletRequest request) {
		StringBuffer buff = new StringBuffer();
		buff.append("<table border='1'>");
		buff.append("<tr><td colspan='2' align='center'>DEBUG</td></tr>");
		buff.append("<tr><th>Parameter</th><th>Value</th></tr>");
		Enumeration en = request.getParameterNames();
		while (en.hasMoreElements()) {
			String name = (String)en.nextElement();
			String value = request.getParameter(name);
			buff.append("<tr><td>").append(name).append("</td><td>").append(value).append("</td></tr>");
		}
		buff.append("<tr><th colspan='2'>JMX Cache</th></tr>");
		try {
			buff.append("<tr><td colspan='2'>" + counter.getCurrentCount() + "</td></tr>");
		} catch (RemoteException e) {
			log.error("", e);
		}
		buff.append("</table>");
		buff.append("<br/>");
		return buff.toString();
	}


}
