/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2008, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package mil.navy.commerce.web;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mil.navy.commerce.db.ControlStat;
import mil.navy.commerce.db.QueueStat;
import mil.navy.commerce.ejb.StatsBean;
import mil.navy.commerce.ejb.StatsLocal;
import mil.navy.commerce.monitor.ChartMaker;

import org.jboss.logging.Logger;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;

/**
 * JMS Queue Monitor Servlet.
 * <p/>
 * It knows how to render all of MC components, or you can specify just a single
 * bean via parameter. e.g. grapher/?bean=TransactionManager
 * <p/>
 * You can also change the type of rendering. Currently we're supporting svg,
 * jpg and gif.
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 */
public class ChartServlet extends HttpServlet {

	private static final long serialVersionUID = -4702014855327158453L;

	private Logger log = Logger.getLogger(getClass());

	@Override
	@SuppressWarnings("unchecked")
	public void init(ServletConfig config) throws ServletException {
		ServletContext context = config.getServletContext();
	}

	/**
	 * Do render MC graph.
	 * 
	 * @param request
	 *            the http request
	 * @param response
	 *            the http response
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             the io exception
	 */
	protected void doRenderGraph(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("image/png");
		OutputStream out = response.getOutputStream();

		ChartMaker maker = new ChartMaker();

		String chart = (String) request.getParameter("chart");
		JFreeChart jchart = null;
		switch (Integer.valueOf(chart)) {
			case ChartMaker.QUEUE_CHART:
				jchart = maker.getChart(ChartMaker.QUEUE_CHART);
				break;
			case ChartMaker.STATS_CHART:
				jchart = maker.getChart(ChartMaker.STATS_CHART);
				break;
			case ChartMaker.PERFORMANCE_CHART:
				List<QueueStat> stats = new ArrayList<QueueStat>();
				try {
					InitialContext ctx = new InitialContext();
					StatsLocal bean = (StatsLocal) ctx.lookup(StatsBean.JNDI_NAME);
					stats = bean.getStats(System.currentTimeMillis()-1, 60000);
				} catch (NamingException e) {
					log.error("Naming error getting statistics:", e);
				}
				maker.setResults(new ArrayList<Serializable>(stats));
				jchart = maker.getChart(ChartMaker.PERFORMANCE_CHART);
				break;
			case ChartMaker.METER_CHART:
				List<ControlStat> cstats = new ArrayList<ControlStat>();
				try {
					InitialContext ctx = new InitialContext();
					StatsLocal bean = (StatsLocal) ctx.lookup(StatsBean.JNDI_NAME);
					cstats = bean.getControlStats(System.currentTimeMillis()-1, 60000);
				} catch (NamingException e) {
					log.error("Naming error getting statistics:", e);
				}
				maker.setResults(new ArrayList<Serializable>(cstats));
				jchart = maker.getChart(ChartMaker.METER_CHART);
				break;
			default:
				jchart = new JFreeChart("Loading...", null, null, false);
		}

		try {
	        ChartUtilities.writeChartAsPNG(out, jchart, 600, 350);
		} finally {
			out.flush();
			out.close();
		}
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doRenderGraph(request, response);
	}

}
