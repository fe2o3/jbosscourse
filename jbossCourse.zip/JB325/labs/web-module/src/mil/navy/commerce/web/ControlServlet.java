/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Inc., and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors.
 *
 */
package mil.navy.commerce.web;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mil.navy.commerce.monitor.JMXLocator;

import org.jboss.ejb3.mdb.MessagingDelegateWrapperMBean;
import org.jboss.logging.Logger;

/**
 * JMS Queue Monitor Controller Servlet. 
 * 
 * <p/>
 * For start/stopping of the JB325 lab Messaging controller MDB.
 * <p/>
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 */
public class ControlServlet extends HttpServlet {

	private static final long serialVersionUID = -4602014855327158454L;

	private Logger log = Logger.getLogger(getClass());

	private boolean mdbRunning = false;

	@Override
	@SuppressWarnings("unchecked")
	public void init(ServletConfig config) throws ServletException {
		ServletContext context = config.getServletContext();
	}

	/**
	 * Control the Quartz MDB
	 * 
	 * @param request
	 *            the http request
	 * @param response
	 *            the http response
	 * @throws ServletException
	 *             the servlet exception
	 * @throws IOException
	 *             the io exception
	 */
	protected void doControl(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");

		String start = (String) request.getParameter("start");
		String stop = (String) request.getParameter("stop");

		try {
			MessagingDelegateWrapperMBean mdb = JMXLocator.getController();
			mdbRunning = (mdb.isDeliveryActive()) ? true:false;
			if (!mdbRunning && start != null)
				mdb.startDelivery();
			else if (mdbRunning && stop != null)
				mdb.stopDelivery();
		} catch (Exception e) {
			log.error("Error controlling Quartz MDB:", e);
		} finally {
			response.sendRedirect("/web-module/monitor.html");
		}
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doControl(request, response);
	}

}
