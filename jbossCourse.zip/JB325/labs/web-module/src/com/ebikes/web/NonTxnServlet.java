package com.ebikes.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.ebikes.ejb.DBManagerBean;
import com.ebikes.ejb.DBManagerLocal;
import com.ebikes.util.DBUtils;
import com.ebikes.util.ServiceLocator;

public class NonTxnServlet extends HttpServlet {

	private static final long serialVersionUID = 7620089370881249844L;

	private static DBManagerLocal manager;

	private static String EXPLANATION_1_CONNECTION_POOLS_1 = "<p>Here, the application executes a query that tries to open 10 connections simultaneously. "
			+ "Since the data source configuration provided with the lab initially sets min and max size of connections to 1, "
			+ "opening multiple connections simultaneously results in a second connection waiting for blocking time-out "
			+ "and eventually throwing an exception: <br/>" + "</p>";

	private static String EXPLANATION_1_CONNECTION_POOLS_2 = "<p><b>Task:</b>"
			+ "<ul> <li><strong>First task</strong>: Change the <tt>BlockingTimeoutMillis</tt> "
			+ "in <tt>no-tx-h2-ds.xml</tt> file found under the <tt>jb325_server/deploy</tt> directory and see the effect, "
			+ "ideally set it to something less than default 30000 (e.g., 5000)."
			+ "When you save the change, the datasource will automatically be redeployed by JBoss. "
			+ "Retest the lab once you make this change by clicking the re-run link.<br/> </li>"
			+ "<li><strong>Second Task</strong>: Change the max size of the pool in the <tt>no-tx-h2-ds.xml</tt> file "
			+ "to accomodate 10 simultaneous connections and then "
			+ "retest the application by clicking the re-run link.</li> </ul></p>";

	private static String EXPLANATION_3_TRANSACTIONS_1 = "<p>Here, a sequence of two insert statements inserts into the tables Customer and Order and is executed three times. "
			+ "The statements insert a new customer as well as a new order belonging to the new customer. "
			+ "If successful, the application displays the id of the inserted rows. You can view the inserted rows "
			+ "in the H2 database using the <a href=\"http://localhost:8082\" target=\"_blank\">database console.</a>"
			+ "<br/>In the second pass of executing this sequence of inserts, we provoke a failure when inserting the order: "
			+ "the order to be inserted has a non-unique id.<br/>"
			+ "So, while the second insert into the Order table fails, the first insert into the Customer table is committed. "
			+ "This leaves the database in an inconsistent state:  "
			+ "it  now contains a customer who has no corresponding order.<br/>"
			+ "The third execution pass inserts yet another new customer and new order. <br/>";

	private static String EXPLANATION_3_TRANSACTIONS_2 = "<p><b>Task:</b></p>"
			+ "<p>Since this is a non-transactional data source, we  have to fix this behaviour of the application "
			+ "manually using capabilities of the resource adaptors.</p>"
			+ "<ul/> <li>Fix the <tt>executeTransaction()</tt> method  of <tt>NonTxnServlet</tt> in such a way that it "
			+ "rolls back the transaction if any of the inserts fails (look for the <tt>FIXMEs</tt>) "
			+ "When you save the changes in JBDS, undeploy the application from JBoss and then redeploy it to make sure "
			+ " the changes are picked up.</li></ul>"
			+ "<p>Once code is fixed to take care of rollback and commits, it should not increment the count of Customer id "
			+ "in the second pass of executing inserts. "
			+ "Rather, it should show the same Customer Id for passes 2 and 3, meaning that in pass 2 no customer has actually "
			+ "been inserted into the database.</p>";

	private static String EXPLANATION_4_CMT_SESSIONBEANS_1 = "<p>Here, the set-up is similar to the set-up of "
			+ "''Using Transactions'' but this time, we use Container Managed Transactions and Session Beans. "
			+ "<br/>Note that since we are passing non transactional data source to the "
			+ "<tt>com.ebikes.ejb.DBManagerBean</tt> EJB in the <tt>ejb-module</tt> project  "
			+ "the container can not propagate the Transaction Context to the data source and eventually "
			+ "ends up with an inconsistency as in the previous test, ''Using Transactions''.</p>";

	private static String EXPLANATION_4_CMT_SESSIONBEANS_2 = "<p><b>Tasks:</b></p><ul>"
			+ "<li>Verify the behaviour of the application by re-executing it (by clicking the re-run link)"
			+ "  and observe how the customer id is incremented.  </li>"
			+ "<li> This time the task is to fix the behaviour of the application automatically  "
			+ "by using a transactional data source. Fix the code in the <tt>doUsingTransactionsCMT()</tt> method in "
			+ "the <tt>NonTxServlet.java</tt> servlet in the <tt>web-module</tt> project in such a way that it "
			+ " passes a transactional data source to <tt>DBManagerBean.java.executeTransaction()</tt>. "
			+ "(Look for the <tt>FIXME</tt>)</li>"
			+ "<li>Verify that it really uses a transactional data source by saving/undeploying/redeploying the application. "
			+ "Now check how the customer id is incremented.</li></ul>";

	private final static String EXPLANATION_5_XA_TRANSACTION_1 = "<p>Here, we use two different data sources in distributed transactions. <br/>"
			+ "A transaction consists of two steps: <ol>"
			+ "<li>Inserting a message into the JMS <tt>testQueue</tt>. </li>"
			+ "<li>Executing an embedded transaction with two inserts into a DB.</li> "
			+ "</ol>The intention is that a message is sent to the message queue only if the insert statements "
			+ "are executed successfully. "
			+ "In order to observe rollbacks in this distributed transaction you will intentionally provoke a "
			+ "failure in the insert statements.</p>";

	private final static String EXPLANATION_5_XA_TRANSACTION_2 = "<h4>Tasks:</h4><p><ul>"
			+ "<li>Modify the <tt>executeXATransaction()</tt> method of the <tt>DBManagerBean</tt> in "
			+ "such a way that it induces a failure in pass 1. (Look for the <tt>FIXME</tt>)</li> "
			+ "<li>Check that it rolls back the JMS changes as well, i.e., that it does not commit the "
			+ "message to the queue if the database inserts fail. The customer id should not be incremented by "
			+ "the failing transaction. "
			+ "Save the change then undeploy/redeploy and verify by clicking the re-run link. "
			+ "</li</ul></p>";

	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		out.println("<html><body>");

		try {
			if (req.getParameter("item") != null) {
				int item = Integer.parseInt(req.getParameter("item"));
				if (item == 1) {
					out.println("<h2>Connection Pools</h2>");
					out.println(EXPLANATION_1_CONNECTION_POOLS_1);
					out.println("<hr/>");
					doConnectionPools(out);
					out.println("<hr/>");
					out.println(EXPLANATION_1_CONNECTION_POOLS_2);
					out
							.println("<a href='NonTxnServlet?item=1'>Re-run ...</a><br/>");
					out.println("<a href='connections.html'>Back to index</a>");
				}
				if (item == 3) {
					out.println("<h2>Using Transactions</h2>");
					out.println(EXPLANATION_3_TRANSACTIONS_1);
					out.println("<hr/>");
					doUsingTransactions(out);
					out.println("<hr/>");
					out.println(EXPLANATION_3_TRANSACTIONS_2);
					out
							.println("<a href='NonTxnServlet?item=3'>Re-run ...<br/></a>");
					out.println("<a href='connections.html'>Back to index</a>");
				}
				if (item == 4) {
					out
							.println("<h2>Using transactions with CMT SessionBeans</h2>");
					out.println(EXPLANATION_4_CMT_SESSIONBEANS_1);
					out.println("<hr/>");
					doUsingTransactionsCMT(out);
					out.println("<hr/>");
					out.println(EXPLANATION_4_CMT_SESSIONBEANS_2);
					out
							.println("<a href='NonTxnServlet?item=4'>Re-run ...</a><br/>");
					out.println("<a href='connections.html'>Back to index</a>");
				}

				if (item == 5) {
					out.println("<h2>Using XA Transactions with JMS</h2>");
					out.println(EXPLANATION_5_XA_TRANSACTION_1);
					out.println("<hr/>");
					doXaTransactions(out);
					out.println("<hr/>");
					out.println(EXPLANATION_5_XA_TRANSACTION_2);
					out
							.println("<a href='NonTxnServlet?item=5'>Re-run ...</a><br/>");
					out.println("<a href='connections.html'>Back to index</a>");
				}

			}
		} catch (NamingException nme) {
			nme.printStackTrace(out);
		} catch (Exception e) {
			e.printStackTrace(out);
		}
		out.println("</body></html>");
		out.flush();
		out.close();
	}

	/**
    *  
    */
	private void doXaTransactions(PrintWriter out) throws NamingException,
			RemoteException, Exception {
		DataSource dataSource = null;
		dataSource = ServiceLocator.getInstance().getXADataSource();
		out.println("<h4>Pass 1: XA transactions</h4>");
		getDBManager().executeXATransaction(dataSource, out);
		out.println("<br />Inserts finished.<br />");
		out.println("<b>Reading messages</b><br />");
		//getDBManager().createMessage();
//		getDBManager().readMessage(out);
		readMessages(out);
		out.println("Finished reading messages.<br />");

		out.println("<h4>Pass 2: XA transactions</h4><p>");
		getDBManager().executeXATransaction_2(dataSource, out);
		out.println("<br />Inserts finished.<br />");
		out.println("<b>Reading messages</b><br />");
		readMessages(out);
		out.println("Finished reading messages.</br>");
	}

	private void doUsingTransactionsCMT(PrintWriter out)
			throws NamingException, RemoteException, Exception {
		out.println("<h4>Pass 1: Executing DBManager.executeTransaction()</h4>");
		DataSource dataSource = null;
		//dataSource = ServiceLocator.getInstance().getNonTxDataSource();
		// FIXME
		 dataSource=ServiceLocator.getInstance().getLocalTxDataSource();
		// insert fails if successFlag is false
		boolean successFlag = false;
		getDBManager().executeTransaction(dataSource, out, successFlag);
		out.println("<h4>Pass 2: Executing DBManager.executeTransaction()</h4>");
		successFlag = true;
		getDBManager().executeTransaction(dataSource, out, successFlag);
	}

	private void doUsingTransactions(PrintWriter out) throws NamingException,
			Exception {
		DataSource dataSource = null;
		dataSource = ServiceLocator.getInstance().getNonTxDataSource();
		out.println("<h4>Pass 1: Executing Inserts</h4>");
		executeTransaction(dataSource, out, true);
		out.println("<h4>Pass 2: Executing Inserts</h4>");
		executeTransaction(dataSource, out, false);
		out.println("<h4>Pass 3: Executing Inserts</h4>");
		executeTransaction(dataSource, out, true);
	}

	private void doConnectionPools(PrintWriter out) throws NamingException,
			Exception {
		DataSource dataSource = null;
		dataSource = ServiceLocator.getInstance().getNonTxDataSource();
		out
				.println("<b>Starting operation: opening multiple database connections....</b><br/>");
		executeQueryMultipleConnections(dataSource, out, 10);
	}

	private void executeQueryMultipleConnections(DataSource ds,
			PrintWriter out, int n) throws Exception {
		try {
			long totalTime = DBUtils.executeCustomerQueryMultipleConnections(
					ds, n);
			out.println("<p>Total time taken to execute " + n + " queries: "
					+ totalTime + " ms</p>");
		} catch (Exception e) {
			e.printStackTrace();
			out.println("<tt>Exception: " + e.getMessage() + "</tt></p>");
		}
	}

	private void executeTransaction(DataSource ds, PrintWriter out,
			boolean successFlag) throws Exception {
		Connection con = null;
		// FIX ME! This method fails while adding a row in Order table, but
		// commits a row in customer table
		// Uncomment code to commit and rollback transaction to ensure data
		// integrity.
		try {
			con = ds.getConnection();
			 con.setAutoCommit(false); // FIXME
			out.println("Inserting a new Customer: ");
			int cid = DBUtils.createCustomer(con, 0, "New Customer");
			out.println("<b>id=" + cid + "</b><br/>");
			out.println("Inserting a new Order: ");
			int oid;
			// insert fails if successFlag is false
			if (successFlag) {
				oid = DBUtils.createOrder(con, 0, cid);
			} else {
				oid = DBUtils.createOrder(con, 1, cid);
			}
			out.println("<b>id=" + oid + "</b><br/>");
			 con.commit(); // FIXME
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			 con.rollback(); // FIXME
			out.println("<tt> Exception: " + sqle.getMessage() + "</tt>");

		} finally {
			if (con != null)
				con.close();
		}
	}

	// for item 5 XA transactions
	private void readMessages(PrintWriter out) throws Exception {
		InitialContext ctx = new InitialContext();

		QueueConnectionFactory factory = (QueueConnectionFactory) ctx
				.lookup("java:/JmsXA");
		Destination queue = (Destination) ctx.lookup("queue/testQueue");

		QueueConnection connection = factory.createQueueConnection();
		QueueSession session = connection.createQueueSession(true, 1);
		MessageConsumer consumer = session.createConsumer(queue);
		connection.start();
		while (true) {
			Message message = consumer.receive(10);
			if (message == null)
				break;
			message.acknowledge();
			out.println("Message:<br/><tt>" + message + "</tt><br/>");
		}
		connection.close();
	}

	private DBManagerLocal getDBManager() throws Exception {
		if (manager == null) {
			InitialContext ctx = new InitialContext();
			manager = (DBManagerLocal) ctx.lookup(DBManagerBean.JNDI_NAME);
		}
		return manager;
	}
}
