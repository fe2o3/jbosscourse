package com.ebikes.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import com.ebikes.ejb.AccountDataBean;
import com.ebikes.ejb.AccountDataLocal;

/**
 * Servlet for accessing AccountDataBean from JBoss server For the Transactions
 * lab in JB325
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 * @version <tt>$Revision: 1 $</tt>
 */
public class AccountDataServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	// FIXME: add the appropriate injection for the EJB here
	private AccountDataLocal ejb;

	// FIXME: Add an injected resource for a UserTransaction (Advanced Task only)
	
	private List<String> errors;
	private int errornbr;
	  
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		ejb = getEJB();		// FIXME: is this needed with injection?
		errors = new ArrayList<String>();

		String instruct = (String) request.getParameter("save");
		boolean isJMS = (instruct.equals("Notify"));

		String NL = "<br>";

		out.println("<html>");
		out.println("<head>");
		out.println("<meta http-equiv='Content-Type' content='text/html'>");
		out.println("<title>(lab-transactions) Transactions Lab</title>");
		out.println("<link rel='StyleSheet' href='lab.css' type='text/css'/>");
		out.println("</head>");
		out.println("<body>");
		out.println("<table id='top' width='100%' cellpadding='10'>");
		out.println("<tr>"
			+ "<td class='headtable'>JB325 Lab: Transactions (lab-transactions)</td>"
			+ "<td width='15%'><img src='images/jb_logo.png'/></td>");
		out.println("</tr></table>");
		out.println("<h1>Setting up database connections:</h1>");
		ejb.RESETDBS();
		out.println("<h2>INITIAL BALANCE:</h2>");
		out.println("      Balance in DB:" + ejb.balance(1) + NL);
		if (isJMS) {
			out.println("<h1>Running Transaction with JMS message ...</h1>");
			doTransaction(true);
			out.println("<h2>BALANCE AFTER JMS INCLUDED:</h2>");
			out.println("      Balance in DB:" + ejb.balance(1) + NL);
		} else {
			out.println("<h1>Running Transaction without JMS message ...</h1>");
			doTransaction(false);
			out.println("<h2>BALANCE AFTER UPDATE WITHOUT JMS:</h2>");
			out.println("      Balance in DB:" + ejb.balance(1) + NL);
		}
		if (errors.size() > 0) {
			out.println("<h3>ERRORS:</h3>");
			out.println("<textarea id='errors' name='errors' cols=80 rows=10>");
			for (String error:errors)
				out.println(error);
			out.println("</textarea>");
		} else {
			out.println("<h3>COMPLETE.</h3>");
		}
		out.println("<form id='backfrm' method='post' action='transactions.html'>");
		out.println("<input id='back' name='back' type='submit' value='Back'/>");
		out.println("</form>");
		out.println("</body></html>");
		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		doGet(request, response);
	}

	/**
	 * Perform the transaction. Catch all errors.
	 * 
	 * @param sendJMS
	 */
	private void doTransaction(boolean sendJMS) 
	{
		try {
			// FIXME: Start a UserTransaction (Advanced Task only)
			ejb.performXATransactions(sendJMS);
			// FIXME: commit the transaction
		} catch (NotSupportedException e) {
			errors.add(e.getCause().getMessage());
		} catch (SystemException e) {
			errors.add(e.getCause().getMessage());
		} catch (SecurityException e) {
			errors.add(e.getCause().getMessage());
		} catch (IllegalStateException e) {
			errors.add(e.getCause().getMessage());
		} catch (RollbackException e) {
			errors.add(e.getCause().getMessage());
		} catch (HeuristicMixedException e) {
			errors.add(e.getCause().getMessage());
		} catch (HeuristicRollbackException e) {
			errors.add(e.getCause().getMessage());
		} catch (RemoteException e) {
			errors.add(e.getCause().getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			errors.add(e.getCause().getMessage());
		}
	}

	private AccountDataLocal getEJB() {

		AccountDataLocal bean = null;
		try {
			Context ic = new InitialContext();
			bean = (AccountDataLocal) ic.lookup(AccountDataBean.JNDI_NAME);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bean;
	}

}
