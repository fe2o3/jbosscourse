package com.ebikes.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ebikes.ejb.VersionBean;
import com.ebikes.ejb.VersionRemote;
import com.ebikes.util.Lib;
import com.ebikes.util.Util;

/**
 * Servlet for accessing Util classes from JBoss server
 * 
 * @author dnorwood@redhat.com
 *
 */
public class VersionServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		VersionRemote ejb = getVersionBean();

		out.println("<html>");
		out.println("<head>");
		out.println("<title>Lab-classloading: Version information</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<h1>Version Information</h1>");
		out.println("<h2>Print version information of each utility class:</h2>");
		out.println("<table border='1' cellpadding='8'>");
		out.println("<tr><th>Called by</th><th>Class</th></tr>");
		out.println("<tr><td><b>Lib: </b></td><td>"
				+ Lib.getInfo() + "</td></tr>");
		out.println("<tr><td><b>EJB: </b></td><td>" + ejb.getVersion()
				+ "</td></tr>");
		out.println("<tr><td><b>Web: </b></td><td>"
				+ Util.getInfo() + "</td></tr>");
		out.println("</table>");
		out.println("<h2>Invoking EJB from Servlet with <tt>Util</tt> instance reference:</h2>");

		try {
			/*
			 * Pass Util instance to EJB
			 */
			String result = ejb.getVersion(new com.ebikes.util.Util());

			out.println("<table border='1' cellpadding='8'>");
			out.println("<tr><td><b>Util instance in EJB </b></td>");
			out.println("<td>" + result + "</td></tr>");
			out.println("</table>");
		} catch (Throwable t) {
			out.println("<PRE>");
			t.printStackTrace(out);
			out.println("</PRE>");
		}

		out.println("</body>");
		out.flush();
		out.close();
	}

	private VersionRemote getVersionBean() {

		VersionRemote bean = null;
		try {
			Context ic = new InitialContext();
			bean = (VersionRemote) ic.lookup(VersionBean.JNDI_NAME);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bean;
	}
}
