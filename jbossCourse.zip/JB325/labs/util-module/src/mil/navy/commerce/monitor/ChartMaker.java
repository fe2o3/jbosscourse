package mil.navy.commerce.monitor;

import java.awt.Color;
import java.io.Serializable;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mil.navy.commerce.db.ControlStat;
import mil.navy.commerce.db.QueueStat;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.ejb3.mdb.MessagingDelegateWrapperMBean;
import org.jboss.jms.server.destination.QueueMBean;
import org.jboss.jms.server.messagecounter.MessageStatistics;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.SeriesException;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RectangleInsets;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * Monitor the JMX Metrics for JBoss Messaging Post Office(s).
 * For the JB325 training class.
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 * 
 */
public class ChartMaker {

	private Log log = LogFactory.getLog(ChartMaker.class);

	private JFreeChart chart;
	private List<Serializable> results;

	public static final int STATS_CHART = 1;
	public static final int QUEUE_CHART = 2;
	public static final int PERFORMANCE_CHART = 3;
	public static final int METER_CHART = 4;

	/**
	 * Monitored Queues
	 */
	private QueueMBean queueA;
	private QueueMBean queueB;
	private QueueMBean queueC;
	private QueueMBean queueD;
	private QueueMBean queueDLQ;

	/**
	 * Default constructor. Locate JMX MBeans for queues and any other required.
	 * 
	 * Note: here we'll make sure that the PostOffice is tracking messages, by
	 * setting the "enable" flag on message counters.
	 */
	public ChartMaker() {
		queueA = JMXLocator.get(JMXLocator.LOCATOR_A);
		queueB = JMXLocator.get(JMXLocator.LOCATOR_B);
		queueC = JMXLocator.get(JMXLocator.LOCATOR_C);
		queueD = JMXLocator.get(JMXLocator.LOCATOR_D);
		queueDLQ = JMXLocator.get(JMXLocator.LOCATOR_DLQ);
	}

	/**
	 * Use this only to retrieve a given chart.
	 * 
	 * @return the chart
	 */
	public JFreeChart getChart(int type) {
		switch (type) {
		case STATS_CHART:
			barChart();
			break;
		case QUEUE_CHART:
			barChart3D();
			break;
		case PERFORMANCE_CHART:
			timeSeries();
			break;
		case METER_CHART:
			meterChart();
			break;
		}
		return chart;
	}

	/**
	 * Create a pie chart
	 */
	private void pieChart() {
		DefaultPieDataset data = new DefaultPieDataset();
		data.setValue("Category 1", 43.2);
		data.setValue("Category 2", 27.9);
		data.setValue("Category 3", 79.5);
		setChart(ChartFactory.createPieChart("Sample Pie Chart", data, true, // legend?
				true, // tooltips?
				false // URLs?
				));
	}

	/**
	 * Create an XY chart
	 */
	private void xyChart() {
		XYSeries series = new XYSeries("Average Size");
		series.add(20.0, 10.0);
		series.add(40.0, 20.0);
		series.add(70.0, 50.0);
		XYDataset xyDataset = new XYSeriesCollection(series);

		chart = ChartFactory.createXYAreaChart("Xy Chart", "", "", xyDataset,
				PlotOrientation.HORIZONTAL, true, false, false);
	}

	/**
	 * Create a Bar chart
	 */
	private void barChart() {
		CategoryChart bar = new CategoryChart();
		bar.title = "Destination Throughput";
		bar.type = CategoryChart.TYPEBAR;
		bar.range = "Messages";
		bar.domain = "Queue";
		bar.orientation = PlotOrientation.VERTICAL;
		try {
			MessageStatistics statsA = queueA.getMessageStatistics();
			MessageStatistics statsB = queueB.getMessageStatistics();
			MessageStatistics statsC = queueC.getMessageStatistics();
			MessageStatistics statsD = queueD.getMessageStatistics();
			bar.dataset.addValue(statsA.getCountDelta(), "Queue A", "Delta");
			bar.dataset.addValue(statsB.getCountDelta(), "Queue B", "Delta");
			bar.dataset.addValue(statsC.getCountDelta(), "Queue C", "Delta");
			bar.dataset.addValue(statsD.getCountDelta(), "Queue D", "Delta");
			bar.dataset.addValue(statsA.getDepth(), "Queue A", "Depth");
			bar.dataset.addValue(statsB.getDepth(), "Queue B", "Depth");
			bar.dataset.addValue(statsC.getDepth(), "Queue C", "Depth");
			bar.dataset.addValue(statsD.getDepth(), "Queue D", "Depth");
			bar.dataset.addValue(statsA.getDepthDelta(), "Queue A", "Delta");
			bar.dataset.addValue(statsB.getDepthDelta(), "Queue B", "Delta");
			bar.dataset.addValue(statsC.getDepthDelta(), "Queue C", "Delta");
			bar.dataset.addValue(statsD.getDepthDelta(), "Queue D", "Delta");
		} catch (Exception e) {
			log.error("Error getting MBean attributes:", e);
		}
		setChart(bar.getChart());
	}

	/**
	 * Create a 3D Bar chart
	 */
	private void barChart3D() {

		CategoryChart bar = new CategoryChart();
		bar.title = "Destination History";
		bar.type = CategoryChart.TYPEBAR3D;
		bar.range = "Total Messages";
		bar.domain = "Queue";
		bar.orientation = PlotOrientation.VERTICAL;

		try {
			bar.dataset.addValue(queueA.getMessageCounter().getCount(),
					"Queue A", "Total");
			bar.dataset.addValue(queueB.getMessageCounter().getCount(),
					"Queue B", "Total");
			bar.dataset.addValue(queueC.getMessageCounter().getCount(),
					"Queue C", "Total");
			bar.dataset.addValue(queueD.getMessageCounter().getCount(),
					"Queue D", "Total");
			bar.dataset.addValue(queueDLQ.getMessageCounter().getCount(),
					"DLQ", "Total");
		} catch (Exception e) {
			log.error("Error getting MBean attributes:", e);
		}
		setChart(bar.getChart());
	}

	/**
	 * Create a Meter chart.
	 * <p>For now, we're just tracking invocations.</p>
	 * 
	 */
	private void meterChart() {

		MessagingDelegateWrapperMBean controller = JMXLocator.getController();
		boolean isRunning = (controller.isDeliveryActive()) ? true:false;

		int total = 0;
		ControlStat stat = null;
		for (Serializable each : results) {
			stat = (ControlStat) each;
			total += stat.getTotalTime();
		}
		
		Map interval = new HashMap();

		MeterChart meter = new MeterChart();
		meter.type = MeterChart.TYPECIRCLE;
		meter.title = "Lab Controller";
		meter.units = "Invocations/Min";
		meter.range = "1,60";
		meter.interval = interval;
		meter.dataset.setValue(results.size());

		setChart(meter.getChart());
		if (!isRunning)
			chart.setBackgroundPaint(Color.RED);
		else
			chart.setBackgroundPaint(Color.GREEN);
	}

	/**
	 * Loop on a series of {@link QueueStat} records. Sets up a TimeSeries plot.
	 * 
	 */
	private void timeSeries() {

		// final TimeSeries mav = MovingAverage.createMovingAverage(eur,
		// "1 hour moving average", 60, 0);
		final TimeSeries queueA = new TimeSeries("QueueA");
		final TimeSeries queueB = new TimeSeries("QueueB");
		final TimeSeries queueC = new TimeSeries("QueueC");
		final TimeSeries queueD = new TimeSeries("QueueD");
		Second second = new Second();
		Calendar calendar = Calendar.getInstance();
		QueueStat stat = null;
		for (Serializable each : results) {
			try {
				stat = (QueueStat) each;
				calendar.setTimeInMillis(stat.getStopTime());
				second = (Second) Second.createInstance(Second.class, calendar
						.getTime(), calendar.getTimeZone());
				if (stat.getQueue().contains("[A]"))
					queueA.addOrUpdate(second, stat.getTotalTime());
				else if (stat.getQueue().contains("[B]"))
					queueB.addOrUpdate(second, stat.getTotalTime());
				else if (stat.getQueue().contains("[C]"))
					queueC.addOrUpdate(second, stat.getTotalTime());
				else if (stat.getQueue().contains("[D]"))
					queueD.addOrUpdate(second, stat.getTotalTime());
			} catch (SeriesException e) {
				log.error("Error adding data to Chart series:", e);
			}
		}
		final TimeSeriesCollection dataset = new TimeSeriesCollection(queueA);
		dataset.addSeries(queueB);
		dataset.addSeries(queueC);
		dataset.addSeries(queueD);
		setChart(ChartFactory.createTimeSeriesChart("Queue Performance",
				"Queue", "Milliseconds Per Message", dataset, true, true, false));
		chart.setBackgroundPaint(Color.white);
		chart.setTextAntiAlias(true);

/*		final XYPlot plot = chart.getXYPlot();
		// plot.setInsets(new Insets(0, 0, 0, 20));
		final Marker marker = new ValueMarker(700.0);
		marker.setPaint(Color.blue);
		marker.setAlpha(0.8f);
		plot.addRangeMarker(marker);
		plot.setBackgroundPaint(null);
		plot.setBackgroundImage(JFreeChart.INFO.getLogo());
		final XYItemRenderer renderer = plot.getRenderer();
		if (renderer instanceof StandardXYItemRenderer) {
			final StandardXYItemRenderer r = (StandardXYItemRenderer) renderer;
			r.setPlotShapes(true);
			r.setShapesFilled(true);
		} */

		XYPlot plot = (XYPlot) chart.getPlot();
		plot.setBackgroundPaint(Color.lightGray);
		plot.setDomainGridlinePaint(Color.white);
		plot.setRangeGridlinePaint(Color.white);
		plot.setAxisOffset(new RectangleInsets(5.0, 5.0, 5.0, 5.0));
		plot.setDomainCrosshairVisible(true);
		plot.setRangeCrosshairVisible(true);
		DateAxis axis = (DateAxis) plot.getDomainAxis();
		axis.setAutoRange(true);

		XYItemRenderer r = chart.getXYPlot().getRenderer();
		if (r instanceof XYLineAndShapeRenderer) {
			XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) r;
			renderer.setBaseShapesVisible(true);
			renderer.setBaseShapesFilled(true);
			renderer.setDrawSeriesLineAsPath(true);
		}
/*		final StandardXYToolTipGenerator g = new StandardXYToolTipGenerator(
				StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT,
				new SimpleDateFormat("d-MMM-yyyy"), new DecimalFormat("0.00"));
		r.setBaseToolTipGenerator(g);*/
	}

	/**
	 * @param chart
	 *            the chart to set
	 */
	public void setChart(JFreeChart chart) {
		this.chart = chart;
	}

	/**
	 * @return the results
	 */
	public List<Serializable> getResults() {
		return results;
	}

	/**
	 * @param results
	 *            the results to set
	 */
	public void setResults(List<Serializable> results) {
		this.results = results;
	}

}
