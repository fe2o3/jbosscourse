package mil.navy.commerce.db;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * Statistical tracker for a JMS Queue
 * For the JB325 training class.
 * 
 * @author dnorwood
 *
 */
@Entity
public class QueueStat implements Serializable
{

	private static final long serialVersionUID = 186925204243433877L;

	@Id @GeneratedValue
	private int id;

	private String queue;
	private Long counter;
	private Long startTime;
	private Long stopTime;

	/**
	 * Default constructor
	 * 
	 * @param queue
	 */
	public QueueStat() {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @param queue
	 */
	public QueueStat(String queue) {
		super();
		this.queue = queue;
	}
	/**
	 * @return the queue
	 */
	public String getQueue() {
		return queue;
	}
	/**
	 * @param queue the queue to set
	 */
	public void setQueue(String queue) {
		this.queue = queue;
	}
	/**
	 * @return the counter
	 */
	public Long getCounter() {
		return counter;
	}
	/**
	 * @param counter the counter to set
	 */
	public void setCounter(Long counter) {
		this.counter = counter;
	}
	/**
	 * @return the start_time
	 */
	public Long getStartTime() {
		return startTime;
	}
	/**
	 * @param start_time the start_time to set
	 */
	public void setStartTime(Long time) {
		this.startTime = time;
	}

	/**
	 * @return the start_time
	 */
	public Long getStopTime() {
		return stopTime;
	}
	/**
	 * @param start_time the start_time to set
	 */
	public void setStopTime(Long time) {
		this.stopTime = time;
	}

	/**
	 * @return the total_time in milliseconds
	 */
	public Long getTotalTime() {
		return this.stopTime - this.startTime;
	}

}
