package mil.navy.commerce.monitor;

import java.util.HashMap;
import java.util.Map;

import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.ejb3.mdb.MessagingDelegateWrapperMBean;
import org.jboss.jms.server.destination.QueueMBean;
import org.jboss.mx.util.MBeanProxy;
import org.jboss.mx.util.MBeanProxyCreationException;
import org.jboss.mx.util.MBeanProxyExt;
import org.jboss.mx.util.MBeanServerLocator;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * LogInterceptor
 * Singleton JMX JMS MBean Service Locator. For the JB325 training labs.
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 * @see <a href='http://java.sun.com/blueprints/corej2eepatterns/Patterns/ServiceLocator.html'>ServiceLocator</a> pattern
 * 
 */
public class JMXLocator {
	
	private static Map<String, QueueMBean> cache;
	private static MessagingDelegateWrapperMBean controller;

	public static final String LOCATOR_A = "jboss.messaging.destination:service=Queue,name=A";
	public static final String LOCATOR_B = "jboss.messaging.destination:service=Queue,name=B";
	public static final String LOCATOR_C = "jboss.messaging.destination:service=Queue,name=C";
	public static final String LOCATOR_D = "jboss.messaging.destination:service=Queue,name=D";
	public static final String LOCATOR_DLQ = "jboss.messaging.destination:service=Queue,name=DLQ";
	public static final String CONTROLLER = "jboss.j2ee:ear=lab13.ear,jar=ejb-module.jar,name=MDBController,service=EJB3";

	private static Log log = LogFactory.getLog(JMXLocator.class);

	private static JMXLocator instance = new JMXLocator();

	/**
	 * Private constructor, per {@linkplain ServiceLocator} pattern 
	 */
	private JMXLocator() {
		// locate the MBeanServer in JBoss
		MBeanServer server = MBeanServerLocator.locateJBoss();
		QueueMBean mbean = null;
		cache = new HashMap<String, QueueMBean>();
		try {
			mbean = (QueueMBean) MBeanProxyExt.create(QueueMBean.class, ObjectName.getInstance(LOCATOR_A),server);
			cache.put(LOCATOR_A, mbean);
			mbean = (QueueMBean) MBeanProxyExt.create(QueueMBean.class, ObjectName.getInstance(LOCATOR_B),server);
			cache.put(LOCATOR_B, mbean);
			mbean = (QueueMBean) MBeanProxyExt.create(QueueMBean.class, ObjectName.getInstance(LOCATOR_C),server);
			cache.put(LOCATOR_C, mbean);
			mbean = (QueueMBean) MBeanProxyExt.create(QueueMBean.class, ObjectName.getInstance(LOCATOR_D),server);
			cache.put(LOCATOR_D, mbean);
			mbean = (QueueMBean) MBeanProxyExt.create(QueueMBean.class, ObjectName.getInstance(LOCATOR_DLQ),server);
			cache.put(LOCATOR_DLQ, mbean);
			controller = (MessagingDelegateWrapperMBean) 
					MBeanProxy.get(MessagingDelegateWrapperMBean.class, ObjectName.getInstance(CONTROLLER), server);
		} catch (MalformedObjectNameException e) {
			log.error("Malformed OName error geting proxy:", e);
		} catch (NullPointerException e) {
			log.error("NP error getting proxy:", e);
		} catch (MBeanProxyCreationException e) {
			log.error("Proxy creation error:", e);
		}
	}

	public static QueueMBean get(String locator) {
		try {
			return instance.getMBean(locator);
		} catch (Exception e) {
			log.error("Error getting MBean proxy:",e);
		}
		return null;
	}

	public static MessagingDelegateWrapperMBean getController() {
		return instance.getMdb();
	}

	protected QueueMBean getMBean(String locator) {
		return cache.get(locator);
	}

	protected MessagingDelegateWrapperMBean getMdb() {
		return controller;
	}

	private long nextTimestamp() {
		return System.currentTimeMillis() / 100;
	}

}
