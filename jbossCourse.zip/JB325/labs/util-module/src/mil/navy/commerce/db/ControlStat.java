package mil.navy.commerce.db;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * Statistical tracker for a JMS Queue
 * 
 * @author dnorwood@redhat.com
 *
 */
@Entity
public class ControlStat implements Serializable
{
	private static final long serialVersionUID = 186923204743433877L;

	@Id @GeneratedValue
	private int id;

	private String job;
	private Long counter;
	private Date lastFired;
	private Long totalTime;

	/**
	 * Default constructor
	 * 
	 * @param queue
	 */
	public ControlStat() {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @param queue
	 */
	public ControlStat(String name) {
		super();
		this.job = name;
	}

	/**
	 * @return the job
	 */
	public String getJob() {
		return job;
	}
	/**
	 * @param job the job to set
	 */
	public void setJob(String job) {
		this.job = job;
	}

	/**
	 * @return the counter
	 */
	public Long getCounter() {
		return counter;
	}
	/**
	 * @param counter the counter to set
	 */
	public void setCounter(Long count) {
		this.counter = count;
	}

	/**
	 * @return the lastFired
	 */
	public Date getLastFired() {
		return lastFired;
	}

	/**
	 * @param lastFired the lastFired to set
	 */
	public void setLastFired(Date lastFired) {
		this.lastFired = lastFired;
	}

	/**
	 * @return the totalTime
	 */
	public Long getTotalTime() {
		return totalTime;
	}

	/**
	 * @param totalTime the totalTime to set
	 */
	public void setTotalTime(Long time) {
		this.totalTime = time;
	}

}
