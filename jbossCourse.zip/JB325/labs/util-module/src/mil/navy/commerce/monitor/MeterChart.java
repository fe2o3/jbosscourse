package mil.navy.commerce.monitor;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.util.Iterator;
import java.util.Map;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.DialShape;
import org.jfree.chart.plot.MeterInterval;
import org.jfree.chart.plot.MeterPlot;
import org.jfree.data.Range;
import org.jfree.data.general.DefaultValueDataset;
import org.jfree.data.general.ValueDataset;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * <p>
 * The MeterChart object 
 * </p>
 * @author <a href="mailto:luke.trevorrow@gmail.com">Luke Trevorrow</a>
 * @version 0.11
 * 
 */
public class MeterChart {
	public final static int TYPECIRCLE = 0;
	public final static int TYPECHORD = 1;
	public final static int TYPEPIE = 2;
	public final static int TYPERAGCIRCLE = 3;
	public final static int TYPERAGCHORD = 4;
	public final static int TYPERAGPIE = 5;
		
	public String title = null;
	public String units = "Percent";
	public String range = "0,100";
	public int type = TYPERAGCIRCLE;
	public DefaultValueDataset dataset = new DefaultValueDataset();
	public Map interval = null;
	//public static PrintWriter out;

	
    /**
     * Creates a new chart instance.
     *
     */
    public MeterChart() {
    }
    
    /**
     * Creates a chart.
     * 
     * @param type       the type of chart: either Chord, Pie, or Circle.
     * @param title      the title of the chart.
     * @param units      the unit of measure for the meter.
     * @param range      the range of the meter chart.
     * @param dataset    the value range for the meter.
     * @param interval   the interval ranges for the legend. Format is <name>=<startval>,<endval>, eg: Low=0,70
     * 
     * @return JFreeChart
     */
    private static JFreeChart createChart(int type, String title, String units, String range,
    		ValueDataset dataset, Map interval) {

    	// create the meter plot
        MeterPlot plot = new MeterPlot(dataset);

        // what type?
        switch (type) {
        case 0: case 3:
        	plot.setDialShape(DialShape.CIRCLE);
        	break;
        case 1: case 4:
        	plot.setDialShape(DialShape.CHORD);
        	break;
        case 2: case 5:
        	plot.setDialShape(DialShape.PIE);
        	break;
        }

/*        for (Iterator it=interval.keySet().iterator(); it.hasNext(); ) {
            Object key = it.next();
            //out.println("Key : " + key);
        }*/
        
        switch (type) {
        case 0: case 1: case 2:
        	// add the intervals based on the data map
        	if (interval != null || interval.isEmpty()) {
        		for (Iterator it=interval.entrySet().iterator(); it.hasNext(); ) {
        			Map.Entry entry = (Map.Entry) it.next();
        			String key = (String) entry.getKey();
        			String value[] = (String[]) entry.getValue();
        			for (int i=0;i != value.length;i++) {
        				String data[] = value[i].split(",");
        				Color colour = null;
        				if (data[0].equalsIgnoreCase("black")) {
        					colour = Color.black;
        				} else if (data[0].equalsIgnoreCase("blue")) {
        					colour = Color.blue;
        				} else if (data[0].equalsIgnoreCase("cyan")) {
        					colour = Color.cyan;
        				} else if (data[0].equalsIgnoreCase("darkgray")) {
        					colour = Color.darkGray;
        				} else if (data[0].equalsIgnoreCase("gray")) {
        					colour = Color.gray;
        				} else if (data[0].equalsIgnoreCase("green")) {
        					colour = Color.green;
        				} else if (data[0].equalsIgnoreCase("lightgray")) {
        					colour = Color.lightGray;
        				} else if (data[0].equalsIgnoreCase("magenta")) {
        					colour = Color.magenta;
        				} else if (data[0].equalsIgnoreCase("orange")) {
        					colour = Color.orange;
        				} else if (data[0].equalsIgnoreCase("pink")) {
        					colour = Color.pink;
        				} else if (data[0].equalsIgnoreCase("red")) {
        					colour = Color.red;
        				} else if (data[0].equalsIgnoreCase("white")) {
        					colour = Color.white;
        				} else if (data[0].equalsIgnoreCase("yellow")) {
        					colour = Color.yellow;
        				}
        				plot.addInterval(new MeterInterval(key,
        					new Range(new Double(data[1]).doubleValue(), new Double(data[2]).doubleValue()),
        					Color.lightGray, new BasicStroke(2.0F), colour));
        			}
        		}
        	}
            break;
        case 3: case 4: case 5:
        	// add the intervals based on the data map
            for (Iterator it=interval.entrySet().iterator(); it.hasNext(); ) {
            	Map.Entry entry = (Map.Entry) it.next();
            	String key = (String) entry.getKey();
            	String value[] = (String[]) entry.getValue();
            	for (int i=0;i != value.length;i++) {
            		//out.println("key : " + key + " value : " + value[i]);
            		String data[] = value[i].split(",");
            		Color colour = null;
            		if (data[0].equalsIgnoreCase("Red")) {
            			//out.println("<br>RED");
            			colour = new Color(255, 0, 0, 128);
            		} else if (data[0].equalsIgnoreCase("Amber")) {
            			//out.println("<br>AMBER");
            			colour = new Color(255, 255, 0, 64);
            		} else if (data[0].equalsIgnoreCase("Green")) {
            			//out.println("<br>GREEN");
            			colour = new Color(0, 255, 0, 64);
            		}
            		plot.addInterval(new MeterInterval(key,
                           	new Range(new Double(data[1]).doubleValue(), new Double(data[2]).doubleValue()),
                           	Color.lightGray, new BasicStroke(2.0F), colour));
            	}
            }
        }
        
     
        // set the units and range
        // store the start and end ranges as I need these to work out the best tick size
        plot.setUnits(units);
        String theRange[] = range.split(",");
        double startRange = new Double(theRange[0]).doubleValue();
        double endRange = new Double(theRange[1]).doubleValue();
        plot.setRange(new Range(startRange, endRange));

        plot.setMeterAngle(260);
        
        // set up the tick marks
        plot.setTickLabelsVisible(true);
        plot.setTickLabelFont(new Font("Dialog", 1, 10));
        plot.setTickLabelPaint(Color.darkGray);
        plot.setTickSize((endRange-startRange)/20);
        plot.setTickPaint(Color.lightGray);
        plot.setValuePaint(Color.black);
        plot.setValueFont(new Font("Dialog", 1, 14));
        plot.setBackgroundPaint(Color.lightGray);
        plot.setNeedlePaint(Color.darkGray);
        plot.setDialBackgroundPaint(Color.white);
        plot.setDialOutlinePaint(Color.gray);
        
        // generate the chart with no legend
        JFreeChart chart = new JFreeChart(title, JFreeChart.DEFAULT_TITLE_FONT, plot, false);
        
        // set the background color for the chart...
        chart.setBackgroundPaint(new Color(240,240,240,240));
       
        return chart;
        
    }
    
    /**
     * Create the Meter Chart
     * 
     * @return JFreeChart
     */
    public JFreeChart getChart() {
    	JFreeChart chart = createChart(type, title, units, range, dataset, interval);
    	return chart;
    }

}
