package mil.navy.commerce.jms;

import java.util.Date;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import mil.navy.commerce.db.ControlStat;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobListener;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * Quartz Job Listener for instrumenting Controller jobs.
 * 
 * @author <a href='mailto:dnorwood@redhat.com'>David Norwood</a>
 * @see <a href='http://www.opensymphony.com/quartz/wikidocs/TutorialLesson7.html'>Quartz JobListener</a>
 * 
 * @version <tt>$Revision: 1 $</tt>
 */
public class MDBJobListener implements JobListener {

	private static Log log = LogFactory.getLog(MDBJobListener.class);

	public static final String NAME = "MDBJobListener";
	public static final String QUEUE_STATS = "queue/testQueue";

	private long executions;
	private Date lastFired;
	private long totalTime;
	private JobDetail job;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.quartz.JobListener#getName()
	 */
	public String getName() {
		return this.NAME;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.quartz.JobListener#jobExecutionVetoed(org.quartz.JobExecutionContext)
	 */
	public void jobExecutionVetoed(JobExecutionContext arg0) {
		// TODO Auto-generated method stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.quartz.JobListener#jobToBeExecuted(org.quartz.JobExecutionContext)
	 */
	public void jobToBeExecuted(JobExecutionContext arg0) {
		// TODO Auto-generated method stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.quartz.JobListener#jobWasExecuted(org.quartz.JobExecutionContext,
	 * org.quartz.JobExecutionException)
	 */
	public void jobWasExecuted(JobExecutionContext arg0,
			JobExecutionException arg1) {

		this.lastFired = arg0.getFireTime();
		this.executions++;
		this.totalTime += arg0.getJobRunTime();
		this.job = arg0.getJobDetail();
		send();
		if (log.isDebugEnabled())
			log.debug("Job " + arg0.getJobDetail().getName() + " executed in "
					+ arg0.getJobRunTime() + " milliseconds.");
	}

	/**
	 * @return the times this job has been executed
	 */
	public long getExecutions() {
		return executions;
	}

	/**
	 * @return the last time the job was fired
	 */
	public Date getLastFired() {
		return lastFired;
	}

	/**
	 * @return the totalTime of all executions
	 */
	public long getTotalTime() {
		return totalTime;
	}

	private void send() {

		Connection c = null;
		Session s = null;
		MessageProducer p = null;
		try {
			InitialContext ctx = new InitialContext();
			QueueConnectionFactory factory = (QueueConnectionFactory) ctx.lookup("ConnectionFactory");
			c = factory.createConnection();
			c.start();
			s = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
			Queue q = (Queue) ctx.lookup(QUEUE_STATS);
			p = s.createProducer(q);
		} catch (NamingException e) {
			log.error("Naming error setting up queue:", e);
		} catch (JMSException e) {
			log.error("JMS error setting up queue:", e);
		}

		ControlStat stat = new ControlStat();
		stat.setCounter(executions);
		stat.setLastFired(lastFired);
		stat.setTotalTime(totalTime);
		stat.setJob(job.getName());

		ObjectMessage om = null;
		try {
			om = s.createObjectMessage();
			om.setObject(stat);
			p.send(om);
			if (log.isDebugEnabled())
				log.debug("Stats message sent to " + p.getDestination());
			c.close();
		} catch (JMSException e) {
			log.error("JMS error sending statistics message:", e);
		} catch (Exception e) {
			log.error("Error sending statistics message:", e);
		} finally {
		}
	}
}
