package gov.electoral.nz;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import org.jboss.cache.pojo.annotation.Replicable;


/*
 * OfficeBallot.java
 *
 * The OfficeBallot object describes a ballot for an office (i.e. President?)
 * This includes the name of the office, the names of the parties registered
 * on the ballot, and the users selection.
 *
 */
@Replicable 
public class OfficeBallot implements Serializable {

	private static final long serialVersionUID = -8785783974947955674L;

	public String officeName;
    
    // Names of the parties registered on the ballot.
    public List<String> partyNames;

    public List<Integer> voteCount;

    public Ballot b;

    public OfficeBallot() {
        partyNames = new ArrayList<String>();
        voteCount = new ArrayList<Integer>();
    }

    public OfficeBallot(String name, List<String> parties) {
        officeName = name;
        partyNames = parties;
        voteCount = new Vector<Integer>();
    }

}
