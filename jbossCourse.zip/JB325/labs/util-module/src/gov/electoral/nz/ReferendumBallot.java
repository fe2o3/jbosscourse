package gov.electoral.nz;

import java.io.Serializable;

import org.jboss.cache.pojo.annotation.Replicable;

/*
 * ReferendumBallot.java
 *
 * The ReferendumBallot object describes a ballot for a referendum
 * This includes the Referendum name and the users selection.
 *
 */
@Replicable
public class ReferendumBallot implements Serializable {

	private static final long serialVersionUID = -4582038440235233173L;

	// The name of the Referendum. The user should already
    // know the description.
    private String name;
    
    // An integer defining the users selection
    // -1 - Abstain (no selection)
    // 0 - Nay (no)
    // 1 - Yay (yes)
    private int selection;

    // Counts for Yays, Nays, and Abstentions
    private int yayCount = 0;
    private int nayCount = 0;
    private int absCount = 0;

    /** Create the default instance */
    public ReferendumBallot() {
        name = "";
        selection = -1;
    }

    /** specify stuff */
    public ReferendumBallot(String rName) {
        name = rName;
        selection = -1;
    }

	/**
	 * @return the referendumName
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param referendumName the referendumName to set
	 */
	public void setName(String rName) {
		name = rName;
	}

	/**
	 * @return the selection
	 */
	public int getSelection() {
		return selection;
	}

	/**
	 * @param selection the selection to set
	 */
	public void setSelection(int selection) {
		this.selection = selection;
	}

	/**
	 * @return the yayCount
	 */
	public int getYayCount() {
		return yayCount;
	}

	/**
	 * @param yayCount the yayCount to set
	 */
	public void setYayCount(int yayCount) {
		this.yayCount = yayCount;
	}

	/**
	 * @return the nayCount
	 */
	public int getNayCount() {
		return nayCount;
	}

	/**
	 * @param nayCount the nayCount to set
	 */
	public void setNayCount(int nayCount) {
		this.nayCount = nayCount;
	}

	/**
	 * @return the absCount
	 */
	public int getAbsCount() {
		return absCount;
	}

	/**
	 * @param absCount the absCount to set
	 */
	public void setAbsCount(int absCount) {
		this.absCount = absCount;
	}

}
