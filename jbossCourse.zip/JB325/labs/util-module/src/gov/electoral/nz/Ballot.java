package gov.electoral.nz;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.jboss.cache.pojo.annotation.Replicable;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * Ballot class for JB325 training.
 *
 * The Ballot object describes a ballot which include a list of
 * Office Ballots and a list of Referendum Ballots.
 * 
 * @author dnorwood@redhat.com
 *
 */
@Replicable
public class Ballot implements Serializable {

	private static final long serialVersionUID = -3300522727286442974L;

	public List<OfficeBallot> officeList;
    
    public List<ReferendumBallot> referendumList;
    
    public Ballot() {
        officeList = new ArrayList<OfficeBallot>();
        referendumList = new ArrayList<ReferendumBallot>();
    }

    public Ballot(List<OfficeBallot> _officeList, List<ReferendumBallot> _referendumList) {
        officeList = _officeList;
        referendumList = _referendumList;
    }
 
}
