package gov.dot.us.aop.impl;

import gov.dot.us.aop.Node;
import gov.dot.us.aop.PropagationManager;
import gov.dot.us.aop.PropagationRule;
import gov.dot.us.aop.StateItem;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * 
 * @author dnorwood
 * @see Ben Wang's tutorial
 *      [http://onjava.com/pub/a/onjava/2005/11/09/jboss-pojo-cache.html]
 */
public class PropagationManagerImpl implements PropagationManager, Serializable 
{
	private Node rootNode_;
	private Map<String, Node> nodeMap_ = new HashMap<String, Node>();
	private transient PropagationRule orRule_;
	private List<String> messages = new ArrayList<String>();
	private int version;

	public Node getRootNode_() {
		return rootNode_;
	}

	public void setRootNode_(Node rootNode_) {
		this.rootNode_ = rootNode_;
	}

	public void setRootNode(String rdn) {
		this.rootNode_ = createNode(rdn, rdn);
	}

	public Map<String, Node> getNodeMap_() {
		return nodeMap_;
	}

	public void setNodeMap_(Map<String, Node> nodeMap_) {
		this.nodeMap_ = nodeMap_;
	}

	public PropagationRule getOrRule_() {
		if (orRule_ == null)
			orRule_ = new ORSummaryRule();
		return orRule_;
	}

	public void setOrRule_(PropagationRule orRule_) {
		this.orRule_ = orRule_;
	}

	public String[] getMessages() {
		return messages.toArray(new String[]{});
	}

	public void addMessage(String message) {
		this.messages.add(message);
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public boolean hasNodes() {
		if (this.rootNode_ == null)
			return false;
		else
			return true;
	}

	public Node createNode(String fdn, String rdn) {
		Node newNode = new NodeImpl();
		newNode.setNodeFDN(fdn);
		newNode.setNodeRDN(rdn);
		newNode.setPropagationRule(this.getOrRule_());

		StateItem summary = new StateItemImpl(0);
		summary.setState(PropagationRule.STATE_OK);
		newNode.setSummaryStateItem(summary);

		registMap(newNode);

		return newNode;
	}

	public void setUpperNode(String upperFdn, String lowerFdn) {
		Node upperNode = findNode(upperFdn);
		Node lowerNode = findNode(lowerFdn);
		if ((upperNode != null) && (lowerNode != null)) {
			upperNode.addChildNode(lowerNode);
			lowerNode.addUpperNode(upperNode);
		}
	}

	public void addNode(String parentFdn, String rdn) {
		Node parent = findNode(parentFdn);
		if (parent != null) {
			Node node = createNode(parentFdn + "." + rdn, rdn);
			node.setParentNode(parent);
			parent.addChildNode(node);

			PropagationRule rule = node.getPropagationRule();
			rule.summaryUpperPropagate(node);
		}
	}

	/**
	 * Add a StateItem to the node. Only adds if the StateItem does
	 * not already exist.
	 */
	public void addStateItem(String parentFdn, long itemId, String name,
			boolean isFailed, int severity) {
		Node node = findNode(parentFdn);
		if (node != null) {
			StateItem item = node.findStateItem(itemId);
			if (item == null) {
				item = new StateItemImpl(itemId);
				item.setState(isFailed);
				item.setName(name);
				node.addStateItem(item);

				PropagationRule rule = node.getPropagationRule();
				rule.summaryUpperPropagate(node);
				
			} else {
				stateChange(node.getNodeFDN(), itemId, isFailed, severity);
			}
			if (item.getMessage() != null)
				addMessage(item.getMessage());
		}
	}

	public void stateChange(String fdn, long itemId, boolean isFailed, int severity) {
		Node node = findNode(fdn);
		if (node != null) {
			PropagationRule rule = node.getPropagationRule();
			rule.changeState(node, itemId, isFailed, severity);
		}
	}

	public Node findNode(String fdn) {
		return (Node) nodeMap_.get(fdn);
	}

	public List<Node> getNodes(String fdn, boolean deep) {
		Node node = null;
		if (fdn.equals(Node.ROOT_NAME))
			node = rootNode_;
		else
			node = findNode(fdn);
		return getChildren(node, deep);
	}

	private List<Node> getChildren(Node node, boolean deep) {

		List<Node> retchildren = new ArrayList<Node>();
		List<Node> children = node.getChildren();
		for (Node child : children) {
			if (deep)
				retchildren.addAll(getChildren(child, true));
			else
				retchildren.add(child);
		}
		return retchildren;
	}

	private void registMap(Node node) {
		this.nodeMap_.put(node.getNodeFDN(), node);
	}

	public String printNodes() {
		return printNode(rootNode_,"");
	}

	public String printNodes(String fdn) {
		Node node = findNode(fdn);
		if (node != null)
			return printNode(node, "");
		else
			return "Not found.";
	}

	private String printNode(Node node, String prefix) {

		if (node == null)
			return "";

		String newline = "<br/>";
		StringBuffer buff = new StringBuffer();

		String state = (node.getSummaryStateItem().getState() == PropagationRule.STATE_OK)
			? "[ok]":"[failed]";

		buff.append(prefix + node.getNodeRDN() + " (Summary : "
				+ node.getSummaryStateItem().getState() + state + ")").append(newline);

		String itemPrefix = prefix + " | ";
		List<StateItem> items = node.getStateItems();
		for (StateItem item : items) {
			buff.append(printStateItem(item, itemPrefix)).append(newline);
		}

		String childPrefix = prefix + " + ";
		List<Node> children = node.getChildren();
		for (Node child : children) {
			buff.append(printNode(child, childPrefix)).append(newline);
		}
		return buff.toString();
	}

	private String printStateItem(StateItem item, String prefix) {
		return prefix + "( name = " + item.getName() + ", id = "
				+ item.getItemId() + ", failed = " + item.getState() + 
				", severity = " + item.getSeverity() + ")";
	}

}
