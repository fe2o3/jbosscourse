package gov.dot.us.aop.impl;

import gov.dot.us.aop.Node;
import gov.dot.us.aop.StateItem;

import java.util.List;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * 
 * @author dnorwood
 * @see Ben Wang's tutorial
 *      [http://onjava.com/pub/a/onjava/2005/11/09/jboss-pojo-cache.html]
 */
public class ORSummaryRule extends AbstractPropagtionRule {

	private static final String RULE_NAME = "OR-Rule";

	public void changeState(Node node, long itemId, boolean isFailed, int severity) {
		super.changeState(node, itemId, isFailed, severity);
	}

	public void summaryUpperPropagate(Node node) {
		long maxSeverity = 0;

		List<StateItem> stateItems = node.getStateItems();
		for (StateItem item:stateItems) {
			maxSeverity = updateMaxSeverity(maxSeverity, item);
		}

		List<Node> children = node.getChildren();
		for (Node child:children) {
			StateItem childSummary = child.getSummaryStateItem();
			maxSeverity = updateMaxSeverity(maxSeverity, childSummary);
		}

		StateItem summaryItem = node.getSummaryStateItem();
		boolean isSummaryChanged = summaryItem.setState(false);

		if (StateItem.STATE_CHANGED == isSummaryChanged) {
			upperPropagate(node);
		}
	}

	public String toString() {
		return RULE_NAME;
	}
}
