package gov.dot.us.service;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import org.jboss.cache.pojo.annotation.Replicable;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * Cache class for JB325 class.
 * 
 * @author dnorwood@redhat.com
 * 
 */
@Replicable
public class WebCache implements Serializable 
{
	private static final long serialVersionUID = -3188842983327010611L;

	private Hashtable<Integer, Map> selectors = new Hashtable<Integer, Map>();

	public static final int COUNTRY_SELECTOR = 1;
	public static final int CITY_SELECTOR = 2;

	public String getSelector(int which) {
		StringBuffer buff = new StringBuffer();
		Map<Integer, String> selector = selectors.get(which);
		buff.append("<option value=''>New</option>");
		if (selector != null)
			for (Integer key : selector.keySet()) {
				buff.append("<option value='").append(key).append(
						"'>").append(selector.get(key)).append("</option>");
			}
		return buff.toString();
	}

	public void addOption(int which, String option) {
		Map<Integer, String> selector = selectors.get(which);
		if (selector == null)
			selector = new HashMap<Integer, String>();
		int index = selector.size();
		if (option != null && !selector.containsValue(option) && option.length() > 0)
			selector.put(index, option);
		selectors.put(which, selector);
	}

	public String getOption(int which, String index) {
		return (String) this.selectors.get(which).get(Integer.valueOf(index));
	}

}
