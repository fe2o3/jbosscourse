package gov.dot.us.aop;

import java.util.List;

import org.jboss.cache.pojo.annotation.Replicable;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * The PropagationManager interface represents "propagation tree". This is the
 * frontend and logical representation of the whole network.
 * 
 * @author dnorwood
 * @see Ben Wang's tutorial
 *      [http://onjava.com/pub/a/onjava/2005/11/09/jboss-pojo-cache.html]
 */
@Replicable
public interface PropagationManager {
	/**
	 * Creates and sets the root <code>Node</code> which has specified RDN to
	 * this propagation tree.
	 * 
	 * @param rdn
	 *            the root <code>Node</code>'s RDN.
	 */
	public void setRootNode(String rdn);

	/**
	 * Creates a new <code>Node</code> object and register to the propagation
	 * tree.
	 * 
	 * @param fdn
	 *            the new <code>Node</code>'s FDN
	 * @param rdn
	 *            the new <code>Node</code>'s RDN
	 * @return created <code>Node</code> object
	 */
	public Node createNode(String fdn, String rdn);

	/**
	 * Creates and appends a new <code>Node</code> to this propagation tree as
	 * the specified <code>Node</code>'s children.
	 * 
	 * @param parentFdn
	 *            the parent <code>Node</code>'s FDN
	 * @param rdn
	 *            the new <code>Node</code>'s RDN
	 */
	public void addNode(String parentFdn, String rdn);

	/**
	 * Sets the <code>Node</code> object to the lower <code>Node</code> object
	 * as a upper node.
	 * 
	 * @param upperFdn
	 *            the upper <code>Node</code>'s FDN
	 * @param lowerFdn
	 *            the lower <code>Node</code>'s FDN
	 */
	public void setUpperNode(String upperFdn, String lowerFdn);

	/**
	 * Creates and appends a new <code>StateItem</code> to the Node identified
	 * by the specified parent FDN and item ID.
	 * 
	 * @param parentFdn
	 *            the parent <code>Node</code>'s FDN
	 * @param itemId
	 *            the new <code>StateItem</code>'s item ID
	 * @param name
	 *            a logical name
	 * @param isFailed a boolean representing if failed
	 */
	public void addStateItem(String parentFdn, long itemId, String name,
			boolean isFailed, int severity);

	/**
	 * If there are any nodes yet, returns a true.
	 * 
	 * @return boolean true if nodes are present
	 */
	public boolean hasNodes();

	/**
	 * Finds the <code>Node</code> identified by the specified FDN. If it can't
	 * find the specified <code>Node</code>, returns <code>null</code>.
	 * 
	 * @param fdn
	 *            the target <code>Node</code>'s FDN.
	 * @return found <code>Node</code> object or <code>null</code>.
	 */
	public Node findNode(String fdn);

	/**
	 * Changes the <code>Node</code>'s state to the specified new state. The
	 * target Node is identified by the specified FDN and item ID.<br />
	 * 
	 * @param fdn
	 *            the target <code>Node</code>'s FDN.
	 * @param itemId
	 *            the target item ID.
	 * @param isFailed a boolean representing failed state
	 * @param severity an int for severity level
	 */
	public void stateChange(String fdn, long itemId, boolean isFailed, int severity);

	/**
	 * Prints the propagation tree's all <code>Node</code>'s and state.
	 * 
	 * @return a <code>String</code> representing the node tree
	 */
	public String printNodes();

	/**
	 * Prints the propagation tree from the <code>Node</code> identified by the
	 * specified FDN.<br />
	 * 
	 * @param fdn
	 *            the top <code>Node</code>'s FDN
	 * @return a <code>String</code> representing the node tree
	 */
	public String printNodes(String fdn);

	/**
	 * Returns a <code>List</code> of <code>Node</code> items
	 * 
	 * @param fdn the top <code>Node</code>'s FDN
	 * @param deep a boolean indicating whether to get the entire tree
	 */
	public List<Node> getNodes(String fdn, boolean deep);

	/**
	 * Returns a <code>String</code> array of messages
	 * 
	 */
	public String[] getMessages();

}
