package gov.dot.us.aop.impl;

import gov.dot.us.aop.Node;
import gov.dot.us.aop.PropagationRule;
import gov.dot.us.aop.StateItem;

import java.util.List;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * 
 * @author dnorwood
 * @see Ben Wang's tutorial
 *      [http://onjava.com/pub/a/onjava/2005/11/09/jboss-pojo-cache.html]
 */
public abstract class AbstractPropagtionRule implements PropagationRule 
{
	public void changeState(Node node, long itemId, boolean isFailed, int severity) {
		StateItem target = node.findStateItem(itemId);
		if (target == null) {
			System.out.println("[Error] StateItem not found. : " + node + ":"
					+ itemId);
			return;
		}

		if (StateItem.STATE_CHANGED == target.setState(isFailed)) {
			summaryUpperPropagate(node);
		}
	}

	protected void upperPropagate(Node node) {
		// propagate to parent node.
		Node parentNode = (Node) node.getParentNode();
		if (parentNode != null) {
			PropagationRule parentRule = parentNode.getPropagationRule();
			if (parentRule != null)
				parentRule.summaryUpperPropagate(parentNode);
		}

		// propagate to upper nodes.
		List<Node> nodes = node.getUpperNodes();
		for (Node upperNode : nodes) {
			PropagationRule upperRule = upperNode.getPropagationRule();
			upperRule.summaryUpperPropagate(upperNode);
		}
	}

	protected boolean isClear(StateItem item) {
		boolean isFailed = item.getState();
		if (isFailed == PropagationRule.STATE_OK) {
			return true;
		} else {
			return false;
		}
	}

	protected long getSeverity(StateItem item) {
		boolean isFailed = item.getState();
		int severity = 0;
		if (true == isSummaryItem(item)) {
			severity = 2;
		} else {
			severity = 4;
		}
		return severity;
	}

	protected boolean isSummaryItem(StateItem item) {
		boolean isFailed = item.getState();
		if (isFailed) {
			return true;
		} else {
			return false;
		}
	}

	protected long updateMaxSeverity(long maxSeverity, StateItem stateItem) {
		if (false == isClear(stateItem)) {
			long severity = getSeverity(stateItem);
			if (severity > maxSeverity) {
				maxSeverity = severity;
			}
		}

		return maxSeverity;
	}
}
