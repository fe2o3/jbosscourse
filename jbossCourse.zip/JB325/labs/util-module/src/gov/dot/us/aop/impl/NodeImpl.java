package gov.dot.us.aop.impl;

import gov.dot.us.aop.Node;
import gov.dot.us.aop.PropagationRule;
import gov.dot.us.aop.StateItem;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * 
 * @author dnorwood
 * @see Ben Wang's tutorial
 *      [http://onjava.com/pub/a/onjava/2005/11/09/jboss-pojo-cache.html]
 * 
 */
public class NodeImpl implements Node, Serializable
{
	private String rdn_;

	private String fdn_;

	private List<Node> childNodes_ = new ArrayList<Node>();

	private List<Node> upperNodes_ = new ArrayList<Node>();

	private Node parentNode_;

	private List<StateItem> stateItems_ = new ArrayList<StateItem>();

	private StateItem summaryItem_;

	private transient PropagationRule rule_ = new ORSummaryRule();

	public void setNodeRDN(String rdn) {
		this.rdn_ = rdn;
	}

	public String getNodeRDN() {
		return this.rdn_;
	}

	public void setNodeFDN(String fdn) {
		this.fdn_ = fdn;
	}

	public String getNodeFDN() {
		return this.fdn_;
	}

	public void addChildNode(Node child) {
		if (child != null) {
			childNodes_.add(child);
		}
	}

	public List<Node> getChildren() {
		return childNodes_;
	}

	public void addUpperNode(Node upperNode) {
		if (upperNode != null) {
			upperNodes_.add(upperNode);
		}
	}

	public List<Node> getUpperNodes() {
		return upperNodes_;
	}

	public void setParentNode(Node parent) {
		if (parent != null) {
			parentNode_ = parent;
		}
	}

	public Node getParentNode() {
		return this.parentNode_;
	}

	public void addStateItem(StateItem stateItem) {
		if (stateItem != null) {
			stateItems_.add(stateItem);
		}
	}

	public void setSummaryStateItem(StateItem stateItem) {
		if (stateItem != null) {
			this.summaryItem_ = stateItem;
		}
	}

	public StateItem getSummaryStateItem() {
		return this.summaryItem_;
	}

	public void setPropagationRule(PropagationRule rule) {
		if (rule != null) {
			this.rule_ = rule;
		}
	}

	public PropagationRule getPropagationRule() {
		return rule_;
	}

	public List<StateItem> getStateItems() {
		return this.stateItems_;
	}

	public StateItem findStateItem(long itemId) {
		StateItem retItem = null;
		int size = stateItems_.size();
		for (int idx = 0; idx < size; idx++) {
			StateItem stateItem = (StateItem) stateItems_.get(idx);
			if (stateItem.getItemId() == itemId) {
				retItem = stateItem;
				break;
			}
		}

		return retItem;
	}

	public String toString() {
		return getNodeFDN();
	}
}
