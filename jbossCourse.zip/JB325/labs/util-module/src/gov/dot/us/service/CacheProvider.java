package gov.dot.us.service;

import javax.management.MBeanServer;
import javax.management.MBeanServerInvocationHandler;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.cache.CacheException;
import org.jboss.cache.pojo.PojoCache;
import org.jboss.cache.pojo.jmx.PojoCacheJmxWrapperMBean;
import org.jboss.mx.util.MBeanServerLocator;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * POJO Cache Service Provider
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 * 
 */
public class CacheProvider {

	/** JBoss PojoCache */
	private static PojoCache cache;
	private static PojoCacheJmxWrapperMBean controller;

	private static final String LOCATOR = "jboss.cache:service=JB325LabCache";

	private static Log log = LogFactory.getLog(CacheProvider.class);
	
	static {
		// locate the MBeanServer in JBoss
		MBeanServer server = MBeanServerLocator.locateJBoss();
		ObjectName objName = null;
		try {
			objName = ObjectName.getInstance(LOCATOR);
			controller = (PojoCacheJmxWrapperMBean) 
				MBeanServerInvocationHandler.newProxyInstance(server, objName, 
						PojoCacheJmxWrapperMBean.class, false);
			cache = controller.getPojoCache();
		} catch (MalformedObjectNameException e) {
			log.error("Malformed OName error:", e);
		} catch (NullPointerException e) {
			log.error("NP error:", e);
		}
		//cache.setCacheMode(TreeCache.REPL_ASYNC);
	}

	public static Object get(String fqn) {
		try {
			return cache.find(fqn);
		} catch (CacheException e) {
			log.error("Cache error:",e);
		} catch (Exception e) {
			log.error("Error:",e);
		}
		return null;
	}

	public static void put(String fqn, Object obj) {
		try {
			cache.attach(fqn, obj);
		} catch (CacheException e) {
			log.error("Cache error:",e);
		} catch (Exception e) {
			log.error("Error:",e);
		}
	}

	public static void evict(String loc) {
		try {
			cache.detach(loc);
		} catch (CacheException e) {
			log.error("Cache error:",e);
		} catch (Exception e) {
			log.error("Error:",e);
		}
	}

	public static String printDetails() {
		try {
			return "NOT IMPLEMENTED.";
		} catch (Exception e) {
			log.error("Error:",e);
			return e.getMessage();
		}
	}

	private long nextTimestamp() {
		return System.currentTimeMillis() / 100;
	}

	/**
	 * 
	 * @return 
	 * @throws Exception
	 * @see org.hibernate.cache.CacheProvider#start(java.util.Properties)
	 */
	public static void start() throws Exception {

		/*
		 * check state in order to start or not the application. Warning
		 * TreeCache has a dependency with org.jboss.system.ServiceController
		 * [TreeCache extends org.jboss.system.ServiceMBeanSupport and
		 * org.jboss.system.ServiceController manages its lifecycle and it
		 * supposes that this object has been registered in our JMX
		 * MBeanServer]. Extend properly in order to avoid this dependency with
		 * JBoss Kernel components, in order to enable easy integration with
		 * other Application Server (like geronimo)
		 */
		int state = controller.getState();
		switch (state) {
		case PojoCacheJmxWrapperMBean.UNREGISTERED:
		case PojoCacheJmxWrapperMBean.REGISTERED:
		case PojoCacheJmxWrapperMBean.CREATED:
			controller.start();
			break;
		case PojoCacheJmxWrapperMBean.STARTED:
			break;
		default:
			break;
		}
	}

	/**
	 * 
	 * @throws Exception
	 * @see org.hibernate.cache.CacheProvider#stop()
	 */
	public static void stop() throws Exception {
		/*
		 * check state in order to start or not the application. See the
		 * comments above.
		 */
		if (cache != null) {
			int state = controller.getState();
			switch (state) {
			case PojoCacheJmxWrapperMBean.UNREGISTERED:
			case PojoCacheJmxWrapperMBean.REGISTERED:
			case PojoCacheJmxWrapperMBean.CREATED:
			case PojoCacheJmxWrapperMBean.STARTED:
				controller.stop();
			case PojoCacheJmxWrapperMBean.STOPPED:
				break;
			default:
				break;
			}
		}
	}

	public boolean isMinimalPutsEnabledByDefault() {
		return true;
	}

}
