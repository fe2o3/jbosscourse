package gov.dot.us.aop;

import org.jboss.cache.pojo.annotation.Replicable;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * The <code>StateItem</code> interface represents an electrical switch to
 * supervise, e.g., a sensor's component like power supply, sensor unit, network IF, etc.
 * A <code>StateItem</code> is distinguished by item id in the associated parent <code>Node</code>.
 * The state field represents device's state (either it's ok or failure).
 * The severity field represents device's failure severity.
 * <p/>
 * </pre>
 *
 * @author y-komori
 * @author dnorwood
 * @see Ben Wang's tutorial
 *      [http://onjava.com/pub/a/onjava/2005/11/09/jboss-pojo-cache.html]
 */
@Replicable
public interface StateItem {

	   /**
	    * A constant which represents a state is changed.
	    */
	   public static final boolean STATE_CHANGED = true;

	   /**
	    * A constant which represents a state is not changed.
	    */
	   public static final boolean STATE_NOT_CHANGED = false;

	   /**
	    * Returns this <code>StateItem</code>'s ID.
	    * The item ID is given only once when a StateItem instance is created.
	    *
	    * @return this <code>StateItem</code>'s item ID
	    */
	   public long getItemId();

	   /**
	    * Sets the specified state to this <code>StateItem</code> object.
	    * As a result of setting the state, returns
	    * <code>StateItem.STATE_CHANGED</code> if it's state is changed from it's
	    * old state.
	    * Returns <code>StateItem.STATE_NOT_CHANGED</code> if it's state stays
	    * constant.
	    *
	    * @param state a state to be set.
	    * @return <code>StateItem.STATE_CHANGED</code> if it's state is changed
	    *         from it's old state, <code>StateItem.STATE_NOT_CHANGED</code>
	    *         if it's state stays constant.
	    */
	   public boolean setState(boolean state);

	   /**
	    * Returns this StateItem's state: false = failed
	    *
	    * @return this StateItem's state
	    */
	   public boolean getState();

	   /**
	    * A logical name to associate with this item.
	    * @param name
	    */ 
	   public void setName(String name);
	   public String getName();

	   /**
	    * A {@link String} message
	    * @param name
	    */ 
	   public void setMessage(String msg);
	   public String getMessage();

	   /**
	    * Severity of the failure
	    * @param level an int
	    */ 
	   public void setSeverity(int level);
	   public int getSeverity();

}
