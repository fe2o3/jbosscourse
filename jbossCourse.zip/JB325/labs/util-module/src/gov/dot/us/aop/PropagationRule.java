package gov.dot.us.aop;

import org.jboss.cache.pojo.annotation.Replicable;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

/**
 * The <code>PropagationRule</code> interface is a summary and propagation
 * logic.<br />
 * This interface's user creates it's instance and sets it to <code>Node</code>
 * objects. The <code>PropagationRule</code> interface don't have states (logic
 * only). So, you have only to create one instance and set to any
 * <code>Node</code>s which you want to use.
 * 
 * @author y-komori
 * @author dnorwood
 * @see Ben Wang's tutorial
 *      [http://onjava.com/pub/a/onjava/2005/11/09/jboss-pojo-cache.html]
 */
@Replicable
public interface PropagationRule 
{
	/**
	 * A constant for failed state. It represents the node is not failed.
	 */
	public static final boolean STATE_OK = false;
	public static final boolean STATE_FAILED = false;

	/**
	 * Changes the specified <code>Node</code>'s <code>StateItem</code> to the
	 * specified state. When the specified <code>StateItem</code>'s state is
	 * changed, calculates and propagates the node's summary state using
	 * <code>summaryUpperPropagate</code> method.
	 * 
	 * @param node
	 *            the node to change state
	 * @param itemId
	 *            the <code>StateItem</code>'s item ID to change state
	 * @param failed a boolean representing failed state
	 * @param int severity
	 * 
	 * @see PropagationRule#summaryUpperPropagate(Node)
	 */
	public void changeState(Node node, long itemId, boolean failed, int severity);

	/**
	 * Calculates the specified <code>Node</code>'s summary state and propagates
	 * to it's parent nodes. This method calculates the specified
	 * <code>Node</code>'s summary state from it's <code>StateItem</code>s and
	 * child <code>Node</code>'s summary.<br />
	 * As a result of summary calculation, when the specified node's summary is
	 * changed, propagates it's summary state to parent and upper nodes calling
	 * their <code>PropagationRule</code>'s <code>changeState</code> method.
	 * 
	 * @param node
	 *            the node to calculate it's summary state
	 */
	public void summaryUpperPropagate(Node node);
}
