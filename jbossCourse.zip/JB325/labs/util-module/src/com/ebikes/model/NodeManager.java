package com.ebikes.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.cache.pojo.annotation.Replicable;

/**
 * Test class for PojoCache for circular references. Link is a POJO that will be
 * instrumented with CacheInterceptor
 * 
 * @version $Revision: 1584 $
 *          <p>
 *          Below is the annotation that signifies this class is "prepared"
 *          under JBossAop. This is used in conjunction with a special
 *          jboss-aop.xml (supplied by JBossCache).
 *          </p>
 */
@Replicable
public class NodeManager {

	private TestNode rootNode_;

	private Map nodeMap_ = new HashMap();

	public NodeManager() {
	}

	public void setRootNode(String rdn) {
		this.rootNode_ = new TestNode();
		rootNode_.setNodeFDN(rdn);
		rootNode_.setNodeRDN(rdn);

		registMap(rootNode_);
	}

	public void addNode(String parentFdn, String rdn) {
		TestNode parent = findNode(parentFdn);
		if (parent != null) {
			TestNode node = new TestNode();
			node.setNodeFDN(parentFdn + "." + rdn);
			node.setNodeRDN(rdn);

			node.setParentNode(parent);
			parent.addChildNode(node);

			registMap(node);
		}
	}

	public TestNode findNode(String fdn) {
		return (TestNode) nodeMap_.get(fdn);
	}

	private void registMap(TestNode node) {
		this.nodeMap_.put(node.getNodeFDN(), node);
	}

	public void printNodes() {
		printNode(rootNode_, "");
	}

	private void printNode(TestNode node, String prefix) {
		System.out.println(prefix + node.getNodeRDN());

		String childPrefix = prefix + " + ";
		List children = node.getChildren();
		int size = children.size();
		for (int idx = 0; idx < size; idx++) {
			TestNode child = (TestNode) children.get(idx);
			printNode(child, childPrefix);
		}
	}

}
