package com.ebikes.model;

import org.jboss.cache.pojo.annotation.Replicable;

/**
 * Sample object that contains administration details.
 * <p>This object is used to illustrate the pojo cache capability of PojoCache. 
 * Note the absence of <code>Serializable</code> interface.</p>
 *
 * @author <a href="mailto:ben.wang@jboss.com">Ben Wang</a>
 *
 */
@Replicable
public class NetworkAdmin
{
   String id_;

   public String getId()
   {
      return id_;
   }

   public void setId(String id)
   {
      id_ = id;
   }

   public String toString()
   {
      StringBuffer sb=new StringBuffer();
      sb.append(" id = ").append(getId());
      return sb.toString();
   }
   
}
