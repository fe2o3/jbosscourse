package com.ebikes.model;

import org.jboss.cache.pojo.annotation.Replicable;

/**
 * Object to test non-primitive key.
 */
@Replicable
public class ValueObject {

	private IdObject idObj;
	private float value;

	public ValueObject() {
	} // ValueObject

	public ValueObject(IdObject aIdObj, float aValue) {
		idObj = aIdObj;
		value = aValue;
	} // ValueObject

	public IdObject getIdObj() {
		return idObj;
	}

	public float getValue() {
		return value;
	}

	public String toString() {
		return idObj + ": " + value;
	} // toString

	public boolean equals(Object aObject) {
		boolean result = false;

		if ((aObject != null)
				&& (aObject.getClass().getName().equals(this.getClass()
						.getName()))) {
			result = idObj.equals(((ValueObject) aObject).idObj);
		} // if

		return result;
	} // equals

	public int hashCode() {
		return idObj.hashCode();
	} // hashCode
} // class ValueObject
