package com.ebikes.model;

import java.util.ArrayList;
import java.util.List;

import org.jboss.cache.pojo.annotation.Replicable;

/**
 * 
 * @author dnorwood
 * 
 */
@Replicable
public class TestNode {

	private String rdn_;

	private String fdn_;

	private List childNodes_ = new ArrayList();

	private TestNode parentNode_;

	public TestNode() {
	}

	public void setNodeRDN(String rdn) {
		this.rdn_ = rdn;
	}

	public String getNodeRDN() {
		return this.rdn_;
	}

	public void setNodeFDN(String fdn) {
		this.fdn_ = fdn;
	}

	public String getNodeFDN() {
		return this.fdn_;
	}

	public void addChildNode(TestNode child) {
		childNodes_.add(child);
	}

	public List getChildren() {
		return childNodes_;
	}

	public void setParentNode(TestNode parent) {
		parentNode_ = parent;
	}

	public TestNode getParentNode() {
		return this.parentNode_;
	}

	public String toString() {
		return getNodeFDN();
	}
}
