package com.ebikes.model;

import org.jboss.cache.pojo.annotation.Replicable;

/**
 * Test class for PojoCache using annotation. This represents a special resource
 * type that can be declared @Transient. That is, it is neither PojoCacheable
 * nor Serializable.
 * 
 * @version $Revision: 1.1.1 $
 */
@Replicable
public class Resource {

	String connection = null;
	String name = null;
	byte[] bin = null;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getConnection() {
		return connection;
	}

	public void setConnection(String connection) {
		this.connection = connection;
	}

	public byte[] getByte() {
		return bin;
	}

	public void setByte(byte[] b) {
		bin = b;
	}

	public String toString() {
		return "name=" + getName() + ", type=" + getConnection();
	}
}
