package com.ebikes.model;

import org.jboss.cache.pojo.annotation.Replicable;

/**
 * Key object that overrides the hashCode that can cause problem for aop.
 */
@Replicable
public class IdObject {

	private String id;

	public IdObject() {
	}

	public IdObject(String aId) {
		id = aId;
	}

	public String toString() {
		return id;
	}

	public boolean equals(Object aObject) {
		boolean result = false;

		if ((aObject != null)
				&& (aObject.getClass().getName().equals(this.getClass()
						.getName()))) {
			if (id.equals(((IdObject) aObject).id)) {
				result = true;
			}
		}
		return result;
	}

	public int hashCode() {
		return id.hashCode();
	}

}

