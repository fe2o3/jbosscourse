package com.ebikes.model;

import java.io.Serializable;

/**
 * Test class for PojoCache.
 * 
 * @version $Revision: 1.1.1 $
 */
public class SerializedAddress implements Serializable {

	String street = null;
	String city = null;
	int zip = 0;

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

	public String toString() {
		return "street=" + getStreet() + ", city=" + getCity() + ", zip="
				+ getZip();
	}

	// public Object writeReplace() {
	// return this;
	// }
}
