package com.ebikes.model;

import org.jboss.cache.pojo.annotation.Replicable;

/**
 * Test class for PojoCache.
 * 
 * @version $Revision: 1.1.1 $
 *          <p>
 *          Below is the annotation that signifies this class is "prepared"
 *          under JBossAop. This is used in conjunction with a special
 *          jboss-aop.xml (supplied by JBossCache). 
 *          </p>
 * 
 */
@Replicable
public class Address {

	String street = null;
	String city = null;
	int zip = 0;

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

	public String toString() {
		return "street=" + getStreet() + ", city=" + getCity() + ", zip="
				+ getZip();
	}

	// public Object writeReplace() {
	// return this;
	// }
}
