package com.ebikes.model;

import java.io.Serializable;

import org.jboss.cache.pojo.annotation.Replicable;

/**
 * Test class for PojoCache. Note that this pojo is both PojoCacheable and
 * Serializable. So user can choose whether to treat this as a Pojo or just a
 * serializable object.
 * 
 * @version $Revision: 1584 $
 */
@Replicable
public class SpecialAddress implements Serializable {

	String addr = null;

	public String getAddr() {
		return addr;
	}

	public void setAddr(String address) {
		this.addr = address;
	}

	public String toString() {
		return "address=" + getAddr();
	}

	// public Object writeReplace() {
	// return this;
	// }
}
