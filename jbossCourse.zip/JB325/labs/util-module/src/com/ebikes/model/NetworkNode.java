package com.ebikes.model;

import java.util.ArrayList;
import java.util.List;

import org.jboss.cache.pojo.annotation.Replicable;

/**
 * Usually corresponds to the physical machine that comparises of various
 * devices.
 * <p>
 * This object is used to illustrate the pojo cache capability of PojoCache.
 * Note the absence of <code>Serializable</code> interface.
 * </p>
 * 
 * @author <a href="mailto:ben.wang@jboss.com">Ben Wang</a>
 * 
 */
@Replicable
public class NetworkNode {

	String name_;
	List elements_;
	String ipAddress_;

	public String getName() {
		return name_;
	}

	public void setName(String name) {
		name_ = name;
	}

	public List getElements() {
		return elements_;
	}

	protected void setElements(List elements) {
		elements_ = elements;
	}

	public void addElement(NetworkElement element) {
		if (elements_ == null)
			elements_ = new ArrayList();

		elements_.add(element);
		element.setParentNode(this);
	}

	public String getIpAddress() {
		return ipAddress_;
	}

	public void setIpAddress(String ipAddress) {
		ipAddress_ = ipAddress;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(" name= ").append(getName()).append(" ipAddress= ").append(
				getIpAddress());
		sb.append(" elements=").append(getElements());
		return sb.toString();
	}

}
