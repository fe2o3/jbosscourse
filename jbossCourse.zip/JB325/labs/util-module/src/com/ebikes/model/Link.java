package com.ebikes.model;

import org.jboss.cache.pojo.annotation.Replicable;

/**
 * Test class for PojoCache for circular references. Link is a POJO that will be
 * instrumented with CacheInterceptor
 * 
 * @version $Revision: 1.1.1 $
 * 
 */
@Replicable
public class Link {

	Link link_;
	String name_;

	public Link() {
	}

	public Link(String name) {
		name_ = name;
	}

	public void setName(String linkName) {
		name_ = linkName;
	}

	public String getName() {
		return name_;
	}

	public void setLink(Link link) {
		link_ = link;
	}

	public Link getLink() {
		return link_;
	}

	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append("Link: name " + name_);
		return buf.toString();
	}
}
