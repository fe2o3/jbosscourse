package com.ebikes.model;

import com.ebikes.cache.CacheObject;

/**
 * Test class for PojoCache. 
 * Student is a POJO that will be instrumented with CacheInterceptor
 * 
 * @version $Revision: 1584 $ 
 * No need to declare annotation here since Person is
 * an instanceof already.
 */
public class Student extends Person {

	private String year;

	// co is Serializable not Advised
	private CacheObject co1;
	private CacheObject co2;

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public CacheObject getCO1() {
		return co1;
	}

	public void setCO1(CacheObject co) {
		this.co1 = co;
	}

	public CacheObject getCO2() {
		return co2;
	}

	public void setCO2(CacheObject co) {
		this.co2 = co;
	}

	public String toString() {
		return "year=" + getYear() + " " + super.toString();
	}

}
