package com.ebikes.model;

import javax.persistence.Transient;

import org.jboss.cache.pojo.annotation.Replicable;
import org.jboss.cache.pojo.annotation.Serializable;

/**
 * Test class for PojoCache using annotation. This object consists of sub-objects
 * that have special annotations.
 *
 * @version $Revision: 1.1.1 $
 */
@Replicable
public class Gadget
{

   String name;
   @Transient Resource resource;
   @Serializable SpecialAddress addr;

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public Resource getResource() {
      return resource;
   }

   public void setResource(Resource resource) {
      this.resource = resource;
   }

   public SpecialAddress getAddr() {
      return addr;
   }

   public void setAddr(SpecialAddress addr) {
      this.addr = addr;
   }

   public String toString()
   {
      return "name=" + getName() + ", resource=" + getResource() + ", SepcialAddress: " + getAddr();
   }
}
