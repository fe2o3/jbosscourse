package mil.navy.commerce.ejb;

import javax.annotation.Resource;
import javax.ejb.MessageDrivenContext;
import javax.interceptor.Interceptors;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.naming.NamingException;

import mil.navy.commerce.jms.MetricInterceptor;
import mil.navy.commerce.jms.Payload;
import mil.navy.commerce.monitor.JMXLocator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.ejb3.mdb.MessagingDelegateWrapperMBean;
import org.jboss.mx.util.MBeanProxy;
import org.jboss.mx.util.MBeanProxyCreationException;
import org.jboss.mx.util.MBeanServerLocator;

/**
 * An MDB base class, for creating Listeners and the Controller.
 * For JB325 labs.
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 * @version <tt>$Revision: 1 $</tt>
 */
// @Interceptors(MetricInterceptor.class)
public abstract class MDBListenerBase extends MDBBase implements MessageListener
{
	protected static Log log = LogFactory.getLog(MDBListenerBase.class);

	public Payload payload;

	@Resource
	private MessageDrivenContext ctx;

	/**
	 * We expect to receive ObjectMessages, each message containing an Integer.Perf key
	 * When we receive the last Integer, we publish a message on the reply
	 * topic.
	 */
	public void onMessage(Message msg) {
		ObjectMessage om = (ObjectMessage) msg;

		try {
			payload = (Payload) om.getObject();
			payload.stop();
		} catch (JMSException e) {
			log.error("JMS error getting message:", e);
		}

		try {
			if (payload.getDeliveryCounter() % 50 == 0)
				publishStats(payload);
		} catch (JMSException e) {
			log.error("JMS error sending stats message:", e);
		} catch (NamingException e) {
			log.error("Naming error getting message data:", e);
		}

		MessagingDelegateWrapperMBean controller = JMXLocator.getController();
		boolean isRunning = (controller.isDeliveryActive()) ? true:false;

		try {
			if (log.isDebugEnabled())
				log.debug("Listener " + log.getClass().getName() 
					+ " received message " + om.getJMSMessageID() 
					+ ", delivery:"+ payload.getDeliveryCounter());
			if (isRunning && payload.getDeliveryCounter() < payload.MAX_DELIVERIES) {
				payload.start(om.getJMSReplyTo().toString());
				publishAnswer(payload, om.getJMSReplyTo());
			} else if (!isRunning || payload.getDeliveryCounter() == payload.MAX_DELIVERIES) {
				publishStats(payload);
			}
		} catch (JMSException e) {
			log.error("JMS error getting message data:", e);
		} catch (NamingException e) {
			log.error("Naming error getting message data:", e);
		} finally {
		}
	}

}
