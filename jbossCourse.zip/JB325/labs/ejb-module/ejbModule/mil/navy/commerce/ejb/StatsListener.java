package mil.navy.commerce.ejb;

import java.util.List;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import mil.navy.commerce.db.ControlStat;
import mil.navy.commerce.db.QueueStat;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.jms.message.TextMessageProxy;

/**
 * An Listener MDB for the JB325 labs. Persists statistics into Hypersonic 
 * (or database of your choice.)
 * Uses {@link META-INF/persistence.xml} as a JPA descriptor.
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 * @version <tt>$Revision: 1 $</tt>
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destination", propertyValue = "queue/A"),
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue") })
public class StatsListener extends MDBListenerBase implements MessageListener 
{
	protected static Log log = LogFactory.getLog(StatsListener.class);

	@PersistenceContext
	private EntityManager em;

	@SuppressWarnings("unchecked")
	@Override
	public void onMessage(Message msg) {
		if (msg instanceof TextMessageProxy)
			return;
		ObjectMessage om = (ObjectMessage) msg;
		try {
			if (om.getObject() instanceof List) {
				List<QueueStat> stats = (List<QueueStat>) om.getObject();
				for (QueueStat stat : stats) {
					em.persist(stat);
				}
				if (log.isDebugEnabled())
					log.debug(stats.size() + " rows written to QUEUESTAT table.");
			} else if (om.getObject() instanceof ControlStat) {
				em.persist((ControlStat) om.getObject());
				if (log.isDebugEnabled())
					log.debug("Added a row to CONTROLSTAT table.");
			}
		} catch (JMSException e) {
			log.error("JMS error getting stat object:", e);
		}
	}

}
