package mil.navy.commerce.ejb;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.jms.Connection;
import javax.jms.ConnectionMetaData;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.naming.NamingException;

import mil.navy.commerce.db.QueueStat;
import mil.navy.commerce.jms.Payload;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * An MDB which is scheduled via the Quartz Scheduler
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 * @version <tt>$Revision: 1 $</tt>
 */
public abstract class MDBBase {
	protected static Log log = LogFactory.getLog(MDBBase.class);

	public static final String QUEUE_A = "queue/A";
	public static final String QUEUE_B = "queue/B";
	public static final String QUEUE_C = "queue/C";
	public static final String QUEUE_D = "queue/D";
	public static final String QUEUE_STATS = "queue/testQueue";

	@Resource(mappedName = "ConnectionFactory")
	protected QueueConnectionFactory jmsFactory;

	@Resource(mappedName = QUEUE_A)
	protected Queue queueA;

	@Resource(mappedName = QUEUE_B)
	protected Queue queueB;

	@Resource(mappedName = QUEUE_C)
	protected Queue queueC;

	@Resource(mappedName = QUEUE_D)
	protected Queue queueD;

	@Resource(mappedName = QUEUE_STATS)
	protected Queue queueStats;

	protected Map<Integer, Queue> pool;
	protected Random balancer;

	@SuppressWarnings("unused")
	@PostConstruct
	private void setUp() {
		pool = new HashMap<Integer, Queue>();
		try {
			log.info("Setting up JMS destinations for LAB:");
			log.info("QueueA = " + queueA.getQueueName());
			log.info("QueueB = " + queueB.getQueueName());
			log.info("QueueC = " + queueC.getQueueName());
			log.info("QueueD = " + queueD.getQueueName());
		} catch (JMSException e) {
			log.error("Error attempting to query queues:", e);
		}
		pool.put(1, queueA);
		pool.put(2, queueB);
		pool.put(3, queueC);
		pool.put(4, queueD);
		balancer = new Random();
	}

	protected void publishAnswer(Serializable obj) throws JMSException,
			NamingException {
		publishAnswer(obj, getDestination());
	}

	protected void publishAnswer(Serializable obj, Destination destination)
			throws JMSException, NamingException {

		Connection c = jmsFactory.createConnection();
		c.start();
		Session s = c.createSession(false, Session.AUTO_ACKNOWLEDGE);

		ObjectMessage om = s.createObjectMessage();
		om.setObject(obj);
		om.setJMSReplyTo(destination);

		MessageProducer p = s.createProducer(destination);
		try {
			p.send(om);
			if (log.isDebugEnabled())
				log.debug("Message sent to " + p.getDestination());
		} catch (Exception e) {
			log.error("Error sending message:", e);
		} finally {
			if (log.isDebugEnabled()) {
				ConnectionMetaData metaData = c.getMetaData();
				String info = "Connection info:"
						+ metaData.getJMSProviderName() + " version "
						+ metaData.getProviderVersion();
				log.debug(info);
			}
			c.close();
		}
	}

	/**
	 * <pre>
	 * Random &quot;load balancer&quot;. Picks a {@java.jms.Queue} to send the
	 * message to.
	 * With java's {@link java.math.Random} function, we need to be
	 * assured we don't get a zero (0).
	 * </pre>
	 * 
	 * @return a {@link Destination} queue object
	 */
	protected Destination getDestination() {
		int picked = 0;
		while (picked == 0) {
			picked = balancer.nextInt(5);
		}
		if (log.isDebugEnabled())
			log.debug("Sending a message to balancer " + picked);
		return pool.get(picked);
	}

	/**
	 * Send payload statistics to the stat queue.
	 * 
	 * @param load a {@link Payload} object
	 * @throws JMSException
	 * @throws NamingException
	 */
	protected void publishStats(Payload load)
		throws JMSException, NamingException {

		if (load.getTimers().isEmpty())
			return;

		Connection c = jmsFactory.createConnection();
		c.start();
		Session s = c.createSession(false, Session.AUTO_ACKNOWLEDGE);

		ObjectMessage om = s.createObjectMessage();
		om.setStringProperty("id", load.getId());
		om.setObject((Serializable) load.getTimers());
		load.getTimers().clear();

		MessageProducer p = s.createProducer(queueStats);
		try {
			p.send(om);
			if (log.isDebugEnabled())
				log.debug("Stats message sent to " + p.getDestination());
		} catch (Exception e) {
			log.error("Error sending statistics message:", e);
		} finally {
			if (log.isDebugEnabled()) {
				ConnectionMetaData metaData = c.getMetaData();
				String info = "Connection info:"
						+ metaData.getJMSProviderName() + " version "
						+ metaData.getProviderVersion();
				log.debug(info);
			}
			c.close();
		}
	}

}
