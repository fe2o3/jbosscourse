package mil.navy.commerce.ejb;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.MessageListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * An MDB for the JB325 labs
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 * @version <tt>$Revision: 1 $</tt>
 */
@MessageDriven(activationConfig = {
	@ActivationConfigProperty(propertyName="destination", propertyValue=MDBListenerA.QUEUE_A),
	@ActivationConfigProperty(propertyName="destinationType", propertyValue="javax.jms.Queue")
})
public class MDBListenerA extends MDBListenerBase implements MessageListener
{
	protected static Log log = LogFactory.getLog(MDBListenerA.class);

}
