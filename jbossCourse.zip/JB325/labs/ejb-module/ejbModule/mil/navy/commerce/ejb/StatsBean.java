package mil.navy.commerce.ejb;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import mil.navy.commerce.db.ControlStat;
import mil.navy.commerce.db.QueueStat;

/**
 * Stateless query EJB for JB325 labs.
 * 
 * @author dnorwood
 *
 */
@Stateless
public class StatsBean implements StatsLocal {

	public static final String JNDI_NAME = "lab13/StatsBean/local";

	@PersistenceContext
	private EntityManager em;

	/* (non-Javadoc)
	 * @see mil.navy.commerce.ejb.StatsLocal#getStats()
	 */
	@SuppressWarnings("unchecked")
	public List<QueueStat> getStats(long start, long length) {

		List<QueueStat> stats = new ArrayList<QueueStat>();
		String EQL = "from QueueStat where startTime between " + (start-length) +
			" and " + start;
		stats = em.createQuery(EQL).getResultList();
		return stats;
	}

	/* (non-Javadoc)
	 * @see mil.navy.commerce.ejb.StatsLocal#getControlStats(long, long)
	 */
	@SuppressWarnings("unchecked")
	public List<ControlStat> getControlStats(long start, long length) {
		Calendar cal = Calendar.getInstance();
		List<ControlStat> stats = new ArrayList<ControlStat>();
		cal.setTimeInMillis(start-length);
		Date begin = cal.getTime();
		cal.setTimeInMillis(start);
		Date end = cal.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String EQL = "from ControlStat where lastFired between '" + sdf.format(begin) +
			"' and '" + sdf.format(end) + "'";
		stats = em.createQuery(EQL).getResultList();
		return stats;
	}

	/* (non-Javadoc)
	 * @see mil.navy.commerce.ejb.StatsLocal#putStat(mil.navy.commerce.db.ControlStat)
	 */
	public void putStat(ControlStat entity) {
		em.persist(entity);
	}

}
