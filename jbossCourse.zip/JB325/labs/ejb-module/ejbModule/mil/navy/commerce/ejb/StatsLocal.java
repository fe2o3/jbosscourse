package mil.navy.commerce.ejb;

import java.util.List;

import javax.ejb.Local;

import mil.navy.commerce.db.ControlStat;
import mil.navy.commerce.db.QueueStat;

@Local
public interface StatsLocal {

	/**
	 * Gets a {@link List} of {@link QueueStat} rows from DB.
	 * 
	 * @param start a long representing the start time in epochal time
	 * @param length a long representing the length in time of the span
	 * @return
	 */
	public List<QueueStat> getStats(long start, long length);

	/**
	 * Gets a {@link List} of {@link ControlStat} rows from DB.
	 * 
	 * @param start a long representing the start time in epochal time
	 * @param length a long representing the length in time of the span
	 * @return
	 */
	public List<ControlStat> getControlStats(long start, long length);

	/**
	 * Saves an entity instance of {@link ControlStat} to the DB.
	 * 
	 * @param entity the {@link ControlStat} entity instance.
	 */
	public void putStat(ControlStat entity);

}
