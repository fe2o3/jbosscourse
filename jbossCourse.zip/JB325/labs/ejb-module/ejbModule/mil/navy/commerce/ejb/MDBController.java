package mil.navy.commerce.ejb;

import javax.annotation.Resource;
import javax.ejb.MessageDrivenContext;
import javax.jms.Destination;

import mil.navy.commerce.jms.MDBJobListener;
import mil.navy.commerce.jms.Payload;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.ejb3.annotation.ResourceAdapter;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.SchedulerException;

/**
 * An MDB which is scheduled via the Quartz Scheduler
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 * @version <tt>$Revision: 1 $</tt>
 */
//@MessageDriven(activationConfig = 
//	{ @ActivationConfigProperty(propertyName = "cronTrigger", propertyValue = "0/5 * * * * ?") })
@ResourceAdapter("quartz-ra.rar")
public class MDBController extends MDBBase implements Job
{
	protected static Log log = LogFactory.getLog(MDBController.class);

	@Resource
	private MessageDrivenContext ctx;

	/**
	 * We expect to receive ObjectMessages, each message containing an Integer.
	 * When we receive the last Integer, we publish a message on the reply
	 * topic.
	 */
	public void execute(JobExecutionContext jctx) 
			throws JobExecutionException {

		Payload payload = (Payload) jctx.get(Payload.IDENTIFIER);
		if (payload == null) {
			payload = new Payload();
		}

		/**
		 * There *should* only be one global job listener pre-attached to this
		 * Scheduler. If you're not getting stats on the Controller, this
		 * may be a reason.
		 */
		try {
			if (jctx.getScheduler().getGlobalJobListeners().size() < 2) {
				MDBJobListener listener = new MDBJobListener();
				jctx.getScheduler().addGlobalJobListener(listener);
				log.info("Added job listener (MDBJobListener)");
			}
		} catch (SchedulerException e) {
			log.error("Scheduler error attempting to add listener:", e);
		}

		try {
			if (payload.getDeliveryCounter() < payload.MAX_DELIVERIES) {
				Destination target = getDestination();
				payload.start(target.toString());
				publishAnswer(payload, target);
			}
		} catch (Exception e) {
			log.error("Failed to send payload message", e);
		}
	}

}
