package mil.navy.commerce.ejb;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.MessageListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * An MDB which is scheduled via the Quartz Scheduler
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 * @version <tt>$Revision: 1 $</tt>
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName="destination", propertyValue=MDBListenerB.QUEUE_B),
		@ActivationConfigProperty(propertyName="destinationType", propertyValue="javax.jms.Queue")
})
public class MDBListenerB extends MDBListenerBase implements MessageListener
{
	protected static Log log = LogFactory.getLog(MDBListenerB.class);

}
