package com.ebikes.util;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.sql.DataSource;

public class DBUtils {

	private static final String INSERT_CUSTOMER = "INSERT INTO CUSTOMER VALUES (?,?)";
	private static final String INSERT_PRODUCT = "INSERT INTO PRODUCT VALUES (?,?,?,?)";
	private static final String INSERT_ORDER = "INSERT INTO ORD VALUES(?,?,?)";
	private static final String INSERT_LINEITEM = "INSERT INTO LINEITEM VALUES(?,?,?,?)";

	public static void executeCustomerQuery(DataSource ds, PrintWriter out)
			throws Exception {
		Connection con = null;
		try {
			con = ds.getConnection();
			PreparedStatement ps = con
					.prepareStatement("select * from Customer");
			ResultSet rs = ps.executeQuery();
			out.println("<table>");
			out.println("<b><tr><td>ID</td><td>NAME</td></tr></b>");
			while (rs.next()) {
				out.println(rs.getInt("id"));
				out.println(rs.getString("name"));
			}
			out.println("</table>");
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException sqle) {
			sqle.printStackTrace(out);
		} finally {
			if (con != null) {
				con.close();
			}
		}
	}

	public static long executeCustomerQueryMultipleTimes(DataSource ds, int n)
			throws Exception {
		Connection con = null;
		long startTime, endTime;
		startTime = new Date().getTime();
		for (int i = 0; i < n; i++) {
			try {
				con = ds.getConnection();
				PreparedStatement ps = con
						.prepareStatement("select * from Customer");
				ResultSet rs = ps.executeQuery();
				rs.close();
				ps.close();
				con.close();
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			} finally {
				if (con != null) {
					con.close();
				}
			}
		}
		endTime = new Date().getTime();
		return endTime - startTime;
	}

	public static long executeCustomerQueryMultipleConnections(DataSource ds,
			int n) throws Exception {
		Connection[] con = new Connection[n];
		long startTime, endTime;
		startTime = new Date().getTime();
		try {
			for (int i = 0; i < n; i++) {
				System.out.println("Getting Connection:" + i);
				con[i] = ds.getConnection();
				PreparedStatement ps = con[i]
						.prepareStatement("select * from Customer");
				ResultSet rs = ps.executeQuery();
				rs.close();
				ps.close();
			}
		} finally {
			for (int i = 0; i < n; i++) {
				if (con[i] != null) {
					con[i].close();
				}
			}
		}
		endTime = new Date().getTime();
		return endTime - startTime;
	}

	public static int createCustomer(DataSource ds, int id, String name)
			throws Exception {
		Connection con = null;
		long startTime, endTime;
		startTime = new Date().getTime();
		try {
			id = id == 0 ? getNextId(ds, "CUSTOMER") + 1 : id;
			con = ds.getConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_CUSTOMER);
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.executeUpdate();
			ps.close();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		endTime = new Date().getTime();
		return id;

	}

	public static int insertProduct(DataSource ds, int id, String name,
			int inventory, double price) throws Exception {
		Connection con = null;
		long startTime, endTime;
		startTime = new Date().getTime();
		try {
			id = id == 0 ? getNextId(ds, "PRODUCT") + 1 : id;
			con = ds.getConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_PRODUCT);
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setInt(3, inventory);
			ps.setDouble(4, price);
			ps.executeUpdate();
			ps.close();
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			return -1;
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		endTime = new Date().getTime();
		return id;

	}

	public static int createOrder(DataSource ds, int id, int custId)
			throws Exception {
		Connection con = null;
		long startTime, endTime;
		startTime = new Date().getTime();
		try {
			id = id == 0 ? getNextId(ds, "ORD") + 1 : id;
			con = ds.getConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_ORDER);
			ps.setInt(1, id);
			ps.setDate(2, new java.sql.Date(new java.util.Date().getTime()));
			ps.setInt(3, custId);
			ps.executeUpdate();
			ps.close();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		endTime = new Date().getTime();
		return id;
	}

	public static boolean addLineItem(DataSource ds, int oid, int lineId,
			int productId, int qty) {
		Connection con = null;
		long startTime, endTime;
		startTime = new Date().getTime();
		try {
			con = ds.getConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_LINEITEM);
			ps.setInt(1, oid);
			ps.setInt(2, lineId);
			ps.setInt(3, productId);
			ps.setInt(4, qty);
			ps.executeUpdate();
			ps.close();
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			return false;
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		endTime = new Date().getTime();
		return true;
	}

	public static int getNextId(DataSource ds, String tableid) throws Exception {
		Connection con = null;
		long startTime, endTime;
		startTime = new Date().getTime();
		int id = -1;
		try {
			con = ds.getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT max(id) from "
					+ tableid);
			ResultSet rs = ps.executeQuery();
			rs.next();
			id = rs.getInt(1);
			ps.close();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		endTime = new Date().getTime();
		return id;
	}

	public static void printCustomerDetails(DataSource ds, PrintWriter out,
			int id) {
		out.println("<b>Details for Customer Id:" + id + "</b>");
		Connection con = null;
		try {
			con = ds.getConnection();
			PreparedStatement ps = con
					.prepareStatement("select * from Customer where id=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			out.println("<table>");
			out.println("<tr><td>ID</td><td>NAME</td></tr>");
			while (rs.next()) {
				out.println("<tr>");
				out.println("<td>" + rs.getInt("id") + "</td>");
				out.println("<td>" + rs.getString("name") + "</td>");
				out.println("</td>");
			}
			out.println("</table>");
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException sqle) {
			sqle.printStackTrace(out);
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public static void printProductDetails(DataSource ds, PrintWriter out,
			int id) {
		out.println("<b>Details for Product Id:" + id + "</b>");
		Connection con = null;
		try {
			con = ds.getConnection();
			PreparedStatement ps = con
					.prepareStatement("select * from Product where id=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			out.println("<table>");
			out
					.println("<tr><td>ID</td><td>NAME</td><td>Inventory</td><td>Price</td></tr>");
			while (rs.next()) {
				out.println("<tr>");
				out.println("<td>" + rs.getInt("id") + "</td>");
				out.println("<td>" + rs.getString("name") + "</td>");
				out.println("<td>" + rs.getInt("inventory") + "</td>");
				out.println("<td>" + rs.getDouble("price") + "</td>");
				out.println("</tr>");
			}
			out.println("</table>");
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException sqle) {
			sqle.printStackTrace(out);
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public static int createCustomer(Connection con, int id, String name)
			throws Exception {
		id = id == 0 ? getNextId(con, "CUSTOMER") + 1 : id;
		// con=ds.getConnection();
		PreparedStatement ps = con.prepareStatement(INSERT_CUSTOMER);
		ps.setInt(1, id);
		ps.setString(2, name);
		ps.executeUpdate();
		ps.close();
		return id;

	}

	public static int createOrder(Connection con, int id, int custId)
			throws Exception {
		id = id == 0 ? getNextId(con, "ORD") + 1 : id;
		PreparedStatement ps = con.prepareStatement(INSERT_ORDER);
		ps.setInt(1, id);
		ps.setDate(2, new java.sql.Date(new java.util.Date().getTime()));
		ps.setInt(3, custId);
		ps.executeUpdate();
		ps.close();
		return id;
	}

	public static int getNextId(Connection con, String tableid)
			throws Exception {

		long startTime, endTime;
		startTime = new Date().getTime();
		int id = -1;
		try {
			PreparedStatement ps = con.prepareStatement("SELECT max(id) from "
					+ tableid);
			ResultSet rs = ps.executeQuery();
			rs.next();
			id = rs.getInt(1);
			ps.close();
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			return -1;
		}
		return id;
	}

	public static long executeMultipleStatements(DataSource ds, PrintWriter out)
			throws Exception {

		long startTime, endTime;
		startTime = new Date().getTime();
		Connection con = null;
		try {
			con = ds.getConnection();
			PreparedStatement ps = con
					.prepareStatement("Select * from CUSTOMER");
			PreparedStatement ps1 = con
					.prepareStatement("Select * from PRODUCT");
			PreparedStatement ps2 = con.prepareStatement("Select * from ORD");
			PreparedStatement ps3 = con.prepareStatement("Select * from USER");
			PreparedStatement ps4 = con
					.prepareStatement("Select * from USERSEC");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
			}
			;
			rs = ps1.executeQuery();
			while (rs.next()) {
			}
			;
			rs = ps2.executeQuery();
			while (rs.next()) {
			}
			;
			rs = ps3.executeQuery();
			while (rs.next()) {
			}
			;
			rs = ps4.executeQuery();
			while (rs.next()) {
			}
			;
			// ps.close();
			endTime = new Date().getTime();
			return endTime - startTime;
		} catch (SQLException sqle) {
			sqle.printStackTrace(out);
			return -1;
		} finally {
			// con.close();
		}

	}

}
