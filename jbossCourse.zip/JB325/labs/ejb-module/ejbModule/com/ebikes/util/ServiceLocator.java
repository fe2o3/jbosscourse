package com.ebikes.util;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class ServiceLocator 
{
	public static final String NONTX_JNDI = "java:H2NoTxDS";	
	public static final String LOCALTX_JNDI = "java:H2LocalTxDS";
	public static final String XATX_JNDI = "java:H2XATxDS";

	private static ServiceLocator serviceLocator = new ServiceLocator();

	public static ServiceLocator getInstance() {
		return serviceLocator;
	}

	public DataSource getNonTxDataSource() throws NamingException {
		return (DataSource) new InitialContext().lookup(NONTX_JNDI);
	}

	public DataSource getLocalTxDataSource() throws NamingException {
		return (DataSource) new InitialContext().lookup(LOCALTX_JNDI);
	}
	
	public DataSource getXADataSource() throws NamingException {
		return (DataSource) new InitialContext().lookup(XATX_JNDI);
	}
}
