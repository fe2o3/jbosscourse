package com.ebikes.util;
import java.io.Serializable;


/**
 * For verification of this class' class loader & name
 * For the EJB tier
 * 
 * @author dnorwood@redhat.com
 *
 */
public class Util implements Serializable {

	private static final long serialVersionUID = 1L;

	public static String getInfo() {
		StringBuffer buff = new StringBuffer();
		buff.append(Util.class.getClassLoader().toString());
		buff.append(Util.class.getCanonicalName());
		return buff.toString();
	};

}
