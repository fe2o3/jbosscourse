package com.ebikes.ejb;

import java.io.PrintWriter;
import java.rmi.RemoteException;

import javax.ejb.Remote;
import javax.sql.DataSource;

@Remote
public interface DBManager {
	public void executeTransaction(DataSource ds,PrintWriter out, boolean successFlag) throws RemoteException;
	public void printCustomerDetails(DataSource ds, PrintWriter out,int id) throws RemoteException;
	public void executeXATransaction(DataSource ds,PrintWriter out) throws RemoteException;
	public void executeXATransaction_2(DataSource ds,PrintWriter out) throws RemoteException;
}
