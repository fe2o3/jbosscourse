package com.ebikes.ejb;

import java.rmi.RemoteException;
import javax.ejb.Local;


@Local
public interface VersionLocal
{
    public String getVersion() throws RemoteException;
    public String getVersion(com.ebikes.util.Util util) throws RemoteException;
    
}
