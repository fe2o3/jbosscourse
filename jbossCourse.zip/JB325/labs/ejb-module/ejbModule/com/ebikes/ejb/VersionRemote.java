package com.ebikes.ejb;

import java.rmi.RemoteException;
import javax.ejb.Remote;


@Remote
public interface VersionRemote
{
    public String getVersion() throws RemoteException;
    public String getVersion(com.ebikes.util.Util util) throws RemoteException;
    
}
