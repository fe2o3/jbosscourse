package com.ebikes.ejb;

import java.io.PrintWriter;
import java.rmi.RemoteException;

import javax.ejb.Local;
import javax.sql.DataSource;

@Local
public interface DBManagerLocal {
	public void executeTransaction(DataSource ds,PrintWriter out, boolean successFlag) throws RemoteException;
	public void printCustomerDetails(DataSource ds, PrintWriter out,int id) throws RemoteException;
	public void executeXATransaction(DataSource ds,PrintWriter out) throws RemoteException;
	public void createMessage() throws Exception;
	public void readMessage(PrintWriter out) throws Exception;
	public void executeXATransaction_2(DataSource ds,PrintWriter out) throws RemoteException;
}
