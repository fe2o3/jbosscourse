package com.ebikes.ejb;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;

import com.ebikes.util.Util;

/**
 * For verification of the loaded Util class loader
 * Deployed as part of the lab's .ear
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 *
 */
@Stateless
public class VersionBean implements VersionRemote

{
	@Resource
	SessionContext ctx;
	
	public static final String JNDI_NAME = "ejb/VersionBean";

	public String getVersion() {
		return Util.getInfo();
	}

	@SuppressWarnings("static-access")
	public String getVersion(com.ebikes.util.Util util) {
		return util.getInfo();
	}

}
