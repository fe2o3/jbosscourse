package com.ebikes.ejb;

import java.rmi.RemoteException;
import javax.ejb.Remote;


@Remote
public interface AccountDataRemote
{
	public void performXATransactions(boolean notify) throws Exception;
	public double balance(int db) throws RemoteException;
	public void RESETDBS() throws RemoteException;
}
