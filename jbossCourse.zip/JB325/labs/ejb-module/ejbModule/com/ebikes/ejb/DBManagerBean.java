package com.ebikes.ejb;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.jms.Destination;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.ebikes.util.DBUtils;

/**
 * Database manager EJB.
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 * @version <tt>$Revision: 1 $</tt>
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class DBManagerBean implements DBManagerLocal
{
	@Resource
	SessionContext sessionContext;

	public static final String JNDI_NAME = "lab6/DBManagerBean/local";
	public static final String DESTINATION = "queue/testQueue";

	public void executeTransaction(DataSource ds, PrintWriter out,
			boolean successFlag) {
		Connection con = null;
		// FIXME This method fails while adding a row in Order table, but
		// commits a row in customer table.
		// Uncomment code to use Transactional DataSource to ensure data
		// integrity.

		try {
			con = ds.getConnection();
			out.println("Inserting a new Customer:");
			int cid = DBUtils.createCustomer(con, 0, "New Customer");
			out.println("<b>id=" + cid + "</b><br/>");
			out.println("Inserting a new Order: ");
			int oid;
			if (successFlag) {
				oid = DBUtils.createOrder(con, 0, cid);
			} else {
				oid = DBUtils.createOrder(con, 1, cid);
			}
			out.println("<b>id=" + oid + "</b><br/>");
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			out.println("<tt> Exception: " + sqle.getMessage() + "</tt>");
			sessionContext.setRollbackOnly();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

	public void printCustomerDetails(DataSource ds, PrintWriter out, int id) {
		DBUtils.printCustomerDetails(ds, out, id);
	}

	public void executeXATransaction(DataSource ds, PrintWriter out) {
		Connection con = null;
		try {
			out.println("<b>Phase 1: Creating message</b><br />");
			createMessage();
			out.println("Message created.<br />");
			out.println("<b>Phase 2: Executing Inserts</b><br />");
			con = ds.getConnection();
			out.println("Inserting a new Customer: ");
			int cid = DBUtils.createCustomer(con, 0, "New Customer");
			out.println("<b>id=" + cid + "</b><br/>");
			out.println("Inserting a new Order: ");

			int oid;
			// insert fails if successFlag is false
			boolean successFlag;
			// FIXME
			successFlag = false;
			// successFlag = false;
			if (successFlag) {
				oid = DBUtils.createOrder(con, 0, cid);
			} else {
				oid = DBUtils.createOrder(con, 1, cid);
			}
			out.println("<b>id=" + oid + "</b>");
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			out.println("<tt> Exception: " + sqle.getMessage() + "</tt>");
			sessionContext.setRollbackOnly();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

	public void executeXATransaction_2(DataSource ds, PrintWriter out) {
		Connection con = null;
		try {
			out.println("<b>Phase 1: Creating message</b><br />");
			createMessage();
			out.println("Message created.<br />");
			out.println("<b>Phase 2: Executing Inserts</b><br />");
			con = ds.getConnection();
			out.println("Inserting a new Customer: ");
			int cid = DBUtils.createCustomer(con, 0, "New Customer");
			out.println("<b>id=" + cid + "</b><br/>");
			out.println("Inserting a new Order: ");

			int oid;
			boolean successFlag;
			successFlag = true;
			if (successFlag) {
				oid = DBUtils.createOrder(con, 0, cid);
			} else {
				oid = DBUtils.createOrder(con, 1, cid);
			}
			out.println("<b>id=" + oid + "</b>");
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			out.println("<tt> Exception: " + sqle.getMessage() + "</tt>");
			sessionContext.setRollbackOnly();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

	public void createMessage() throws Exception {
		InitialContext ctx = new InitialContext();
		QueueConnectionFactory factory = (QueueConnectionFactory) ctx
				.lookup("java:/JmsXA");
		Destination queue = (Destination) ctx.lookup(DESTINATION);
		QueueConnection connection = factory.createQueueConnection();
		QueueSession session = connection.createQueueSession(true, 1);
		MessageProducer producer = session.createProducer(queue);
		TextMessage message = session.createTextMessage();
		message.setText("This is a message sent from executeXATransaction");
		connection.start();
		producer.send(message);
		connection.close();
	}

	public void readMessage(PrintWriter out) throws Exception {
		InitialContext ctx = new InitialContext();
		QueueConnectionFactory factory = (QueueConnectionFactory) ctx
				.lookup("java:/JmsXA");
		Destination queue = (Destination) ctx.lookup(DESTINATION);
		QueueConnection connection = factory.createQueueConnection();
		QueueSession session = connection.createQueueSession(true, 1);
		MessageConsumer consumer = session.createConsumer(queue);
		connection.start();
		while (true) {
			Message message = consumer.receive(10);
			if (message == null)
				break;
			message.acknowledge();
			out.println("Message:<br/>" + message + ".<br/>");
		}
		connection.close();
	}

}
