package gov.state.ca.ejb;

import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.ejb.Stateless;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.ejb3.annotation.Clustered;

/**
 * A simple stateless EJB for demonstrating clustering and
 * fail-over functionality in JBoss.
 * Goes with JB325 lab9.
 * 
 * @author David Norwood <dnorwood@redhat.com>
 *
 */
@Stateful
@Clustered
public class CarCounterBean implements CarCounter {

	private Log log = LogFactory.getLog(CarCounterBean.class);

	@Resource
	SessionContext ctx;

	public static final String JNDI_NAME = "ejb/CarCounterBean";

	private long count = 0;
	private int  speed = 0;

	
	public long addCounter(long newCount) {
		count += newCount;
		log.info("Total car count: " + count + "( +" + newCount + " )");
		return count;
	}

	
	public long getCurrentCount() {
		return count;
	}

	public void setSpeed(int newspeed) {
		this.speed = newspeed;
	}

	public int getSpeed() {
		return this.speed;
	}

}
