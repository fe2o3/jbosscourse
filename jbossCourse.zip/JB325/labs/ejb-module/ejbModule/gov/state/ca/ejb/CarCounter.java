package gov.state.ca.ejb;


import java.rmi.RemoteException;

import javax.ejb.Remote;

/**
 * Interface for a simple stateless EJB. 
 * For demonstrating clustering and fail-over functionality 
 * in JBoss.
 * 
 * @author David Norwood <dnorwood@redhat.com>
 *
 */
@Remote
public interface CarCounter 
{
	public long addCounter (long newArrests) throws RemoteException;
	public long getCurrentCount () throws RemoteException;
	public void setSpeed (int speed) throws RemoteException;
	public int getSpeed () throws RemoteException;
}
