package gov.dot.us.ejb;

import gov.dot.us.aop.PropagationManager;
import gov.dot.us.service.WebCache;

import javax.ejb.Remote;

import com.ebikes.model.Person;

@Remote
public interface StatelessAction {

	public void addPerson(Person p);
	public void deletePerson(Person p);
	public PropagationManager getManager();
	public WebCache getWebCache();
	public void snapShot(PropagationManager ipm, WebCache iwc);
	public String printCache();

}
