package gov.dot.us.ejb;

import gov.dot.us.aop.PropagationManager;
import gov.dot.us.aop.impl.PropagationManagerImpl;
import gov.dot.us.service.CacheProvider;
import gov.dot.us.service.WebCache;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.management.MalformedObjectNameException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.TransactionManager;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ebikes.model.Person;

@Stateless
@TransactionManagement(value = TransactionManagementType.CONTAINER)
public class StatelessActionBean implements StatelessAction {

	private Log log = LogFactory.getLog(StatelessActionBean.class);

	@Resource
	SessionContext ctx;

	public static final String JNDI_NAME = "lab8/StatelessActionBean/remote";

	private static final String CACHE_REGION = "_LABCACHE_";
	private static final String WEB_REGION = "_WEB_";

	private static TransactionManager tm;
	private static PropagationManager pm;
	private static WebCache wc;

	@PostConstruct
	private void setUp() {
		try {
			CacheProvider.start(); // kick start tree cache
		} catch (MalformedObjectNameException e) {
			log.error("ObjectName error:", e);
		} catch (NullPointerException e) {
			log.error("Null error:", e);
		} catch (Exception e) {
			log.error("Error starting cache:", e);
		}
	}

	@PreDestroy
	private void tearDown() {
		try {
			CacheProvider.stop();
		} catch (Exception e) {
			log.error("Error stopping cache:", e);
		}
	}

	/**
	 * Gets the {@link PropagationManager} object
	 * TODO: we have a work-around here, due possibly to a bug in JBoss Cache.
	 *       Sometimes a {@link ClassCastException} is thrown on 2nd access.
	 */
	public PropagationManager getManager() {
		try {
			pm = (PropagationManager) CacheProvider.get(CACHE_REGION);
		} catch (ClassCastException e) {
			log.error("Caught ClassCast error:", e);
			pm = null;
		}
		if (pm == null)
			pm = new PropagationManagerImpl();
		else
			log.info("got PropagationManager from cache...");
		return pm;
	}

	/**
	 * Gets the {@link WebCache} object
	 * TODO: we have a work-around here, due possibly to a bug in JBoss Cache.
	 *       Sometimes a {@link ClassCastException} is thrown on 2nd access.
	 */
	public WebCache getWebCache() {
		try {
			wc = (WebCache) CacheProvider.get(WEB_REGION);
		} catch (ClassCastException e) {
			log.error("Caught ClassCast error:", e);
			wc = null;
		}
		if (wc == null)
			wc = new WebCache();
		else
			log.info("got WebCache from cache...");
		return wc;
	}

	public String printCache() {
		return CacheProvider.printDetails();
	}

	public void snapShot(PropagationManager ipm, WebCache iwc) {
		CacheProvider.put(CACHE_REGION + "/", ipm);
		CacheProvider.put(WEB_REGION + "/", iwc);
	}

	public void addPerson(Person p) {

		try {
			tm.begin();
		} catch (NotSupportedException e) {
			log.error("Not supported:", e);
		} catch (SystemException e) {
			log.error("System error:", e);
		}

		try {
			CacheProvider.put(CACHE_REGION + "/" + p.getName(), p);
		} catch (Exception e) {
			log.error("Cache error:", e);
		}

		// since it is aop-sanctioned, use of plain get/set methods will take
		// care of cache content automatically.
		// This is also transacted.
		try {
			tm.commit();
		} catch (SecurityException e) {
			log.error("Security error:", e);
		} catch (IllegalStateException e) {
			log.error("State error:", e);
		} catch (SystemException e) {
			log.error("System error:", e);
		} catch (RollbackException e) {
			log.error("Rollback error:", e);
		} catch (HeuristicMixedException e) {
			log.error("Heuristic error:", e);
		} catch (HeuristicRollbackException e) {
			log.error("Heuristic rollback error:", e);
		}

	}

	public void deletePerson(Person p) {

		try {
			tm.begin();
		} catch (NotSupportedException e) {
			log.error("Not supported:", e);
		} catch (SystemException e) {
			log.error("System error:", e);
		}

		try {
			CacheProvider.evict(CACHE_REGION + "/" + p.getName());
		} catch (Exception e) {
			log.error("Cache error:", e);
		}

		// since it is aop-sanctioned, use of plain get/set methods will take
		// care of cache content automatically.
		// This is also transacted.
		try {
			tm.commit();
		} catch (SecurityException e) {
			log.error("Security error:", e);
		} catch (IllegalStateException e) {
			log.error("State error:", e);
		} catch (SystemException e) {
			log.error("System error:", e);
		} catch (RollbackException e) {
			log.error("Rollback error:", e);
		} catch (HeuristicMixedException e) {
			log.error("Heuristic error:", e);
		} catch (HeuristicRollbackException e) {
			log.error("Heuristic rollback error:", e);
		}

	}

}
