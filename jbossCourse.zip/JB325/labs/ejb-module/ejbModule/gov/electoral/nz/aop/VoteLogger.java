package gov.electoral.nz.aop;

import java.util.List;

import gov.electoral.nz.Ballot;
import gov.electoral.nz.OfficeBallot;
import gov.electoral.nz.ejb.VotingBooth;
import gov.electoral.nz.ejb.VotingBoothBean;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

public class VoteLogger {

	private static Log log = LogFactory.getLog(VoteLogger.class);

	// Implement the code to complete this class here.
	@AroundInvoke
	public Object logStuff(InvocationContext inv) throws Exception
	{
		
		String val="";
		List<OfficeBallot> OB=((VotingBoothBean)inv.getTarget()).getBallot().officeList;
		for (OfficeBallot officeBallot : OB) {
			val+=officeBallot.officeName;
		}
		log.info(val);
		
		Object retval=inv.proceed();
		
		
		return retval;
		
		
		
	}

}
