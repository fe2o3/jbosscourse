package gov.electoral.nz.ejb;

import gov.electoral.nz.Ballot;

import javax.ejb.Remote;

@Remote
public interface VotingBooth {

	/**
	 * Login - Begins a 'session' with the server.
	 * 
	 * @param name a {@link String} that uniquely identifies the client.
	 * @return a {@link String} representing the unique session ID to be used in
	 *         all subsequent calls to the server.
	 */
	public String login(String name);

	/**
	 * getBallot - Returns a Ballot object relevant for the session ID
	 * 
	 * @return a {@link Ballot} object, randomly filled with vote
	 */
	public Ballot getBallot();
	
	/**
	 * Accepts and stores the user's ballot selections on the server.
	 * @param sessionID a {@link String} representing unique session id
	 * @param a {@link Ballot} object returned by Login() 
	 * @return
	 */
	public boolean vote(String sessionID, Ballot ballot);

	/**
	 * Returns a listing of results for the current ballot.
	 * @param sessionID a {@link String} representing unique session id
	 * @param a {@link Ballot} containing results for this session's ballot
	 */
	public Ballot getResults(String sessionID);

	/**
	 * Logs the Session out from the server.
	 * @param sessionID
	 */
	public void logout(String sessionID);

	/**
	 * Returns a String of the Map's value
	 * @param index an int for the HashMap index
	 * @return a {@link String} value from the HashMap
	 */
	public String getParty(int index);

	/**
	 * Returns a String of the Map's value
	 * @param index an int for the HashMap index
	 * @return a {@link String} value from the HashMap
	 */
	public String getPosition(int index);

}
