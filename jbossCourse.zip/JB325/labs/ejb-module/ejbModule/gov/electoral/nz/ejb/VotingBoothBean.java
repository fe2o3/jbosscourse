package gov.electoral.nz.ejb;

import gov.electoral.nz.Ballot;
import gov.electoral.nz.OfficeBallot;
import gov.electoral.nz.ReferendumBallot;
import gov.electoral.nz.aop.VoteLogger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.interceptor.Interceptors;
import javax.management.MBeanServer;
import javax.management.MBeanServerInvocationHandler;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.cache.CacheException;
import org.jboss.cache.pojo.PojoCache;
import org.jboss.cache.pojo.jmx.PojoCacheJmxWrapperMBean;
import org.jboss.mx.util.MBeanServerLocator;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

@Stateless
@TransactionManagement(value = TransactionManagementType.CONTAINER)
@Interceptors(VoteLogger.class)
public class VotingBoothBean implements VotingBooth {

	private static Log log = LogFactory.getLog(VotingBoothBean.class);

	public static final String JNDI_NAME = "lab4/VotingBoothBean/remote";

	private Map<String, String> voters;
	private Map<Integer, String> partyNames;
	private Map<Integer, String> positions;

	private PojoCache cache;
	private static final String CACHE_FQN  = "lab4/votes/";
	private static final String VOTERS_FQN = "lab4/voters/";

	@PostConstruct
	private void setUp() {
		partyNames = new HashMap<Integer, String>();
		partyNames.put(0, "Workers");
		partyNames.put(1, "National");
		partyNames.put(2, "Green");
		partyNames.put(3, "Labour");
		partyNames.put(4, "Maori");
		partyNames.put(5, "ACT");
		partyNames.put(6, "United Future");
		partyNames.put(7, "Progressive");
		partyNames.put(8, "Kiwi");
		partyNames.put(9, "Cannabis");

		positions = new HashMap<Integer, String>();
		positions.put(0, "Prime Minister");
		positions.put(1, "Minister for Gaming");
		positions.put(2, "Deputy Prime Minister");
		positions.put(3, "Minister of Finance");
		positions.put(4, "Deputy Prime Minister");
		positions.put(5, "Minister for Infrastructure");
		positions.put(6, "Minister of Civil Defence");
		positions.put(7, "Minister for Internal Affairs");
		positions.put(8, "Minister for Political Action");
		positions.put(9, "Minister for Beverage Usage");

		MBeanServer server = MBeanServerLocator.locateJBoss();
		try {
			ObjectName on = new ObjectName("jboss.cache:service=JB325LabCache");
			PojoCacheJmxWrapperMBean cacheWrapper = (PojoCacheJmxWrapperMBean) 
				MBeanServerInvocationHandler.newProxyInstance(server, on, 
						PojoCacheJmxWrapperMBean.class, false);
			cache = cacheWrapper.getPojoCache();
		} catch (MalformedObjectNameException e) {
			log.error("Object error finding MBean:", e);
		} catch (NullPointerException e) {
			log.error("NP error finding MBean:", e);
		}
		
	}
	
	/* (non-Javadoc)
	 * @see gov.electoral.nz.ejb.VoteCaster#getBallot(java.lang.String)
	 */
	public Ballot getBallot() {
		Random rand = new Random();	// pick a party

		int loc=0;
		List<String> parties = new ArrayList<String>();
		for (int i = 0; i < 3; i++) {
			loc = rand.nextInt(partyNames.size());
			log.debug("Got " + loc + ":" + partyNames.get(loc));
			parties.add(partyNames.get(loc));
		}

		loc = rand.nextInt(positions.size());
		log.debug("Got " + loc + ":" + positions.get(loc));
		OfficeBallot ob = new OfficeBallot(positions.get(loc), parties);

		Ballot b = new Ballot();
		b.officeList.add(ob);
		b.referendumList.add(new ReferendumBallot("Referendum 1"));
		b.referendumList.add(new ReferendumBallot("Referendum 2"));

		return b;
	}

	/* (non-Javadoc)
	 * @see gov.electoral.nz.ejb.VoteCaster#Login(java.lang.String)
	 */
	public String login(String name) {
		Random rand = new Random();
		int sID = rand.nextInt(9999999);
		String sessionID = String.valueOf(sID);
		registerVoter(sessionID, name);
		log.debug("User " + name + " logged in as " + sessionID);
		return sessionID;
	}

	/* (non-Javadoc)
	 * @see gov.electoral.nz.ejb.VoteCaster#Logout(java.lang.String)
	 */
	public void logout(String sessionID) {
		try {
			voters = (Map) cache.find(VOTERS_FQN);
			voters.remove(sessionID);
			cache.attach(VOTERS_FQN, voters);
		} catch (CacheException e) {
			log.error("Error getting from cache:", e);
		}
	}

	/* (non-Javadoc)
	 * @see gov.electoral.nz.ejb.VoteCaster#Vote(java.lang.String, gov.electoral.nz.Ballot)
	 */
	public boolean vote(String sessionID, Ballot ballot) {
		Ballot test = null;
		try {
			voters = (Map) cache.find(VOTERS_FQN);
			test = (Ballot) cache.find(CACHE_FQN + sessionID);
			if (test != null) {
				log.error("Voter " + voters.get(sessionID) + " has already voted.");
				return false;
			} else
				cache.attach(CACHE_FQN + sessionID, ballot);
		} catch (CacheException e) {
			log.error("Error getting from cache:", e);
		}
		log.debug("User " + voters.get(sessionID) + " voted.");
		return true;
	}

	/* (non-Javadoc)
	 * @see gov.electoral.nz.ejb.VoteCaster#getResults(java.lang.String)
	 */
	public Ballot getResults(String sessionID) {
		Ballot found = null;
		try {
			found = (Ballot) cache.find(CACHE_FQN + sessionID);
			if (found == null)
				found = new Ballot();
		} catch (CacheException e) {
			log.error("Error getting cache:", e);
		}
		return found;
	}

	public String getParty(int loc) {
		return partyNames.get(loc);
	}

	public String getPosition(int loc) {
		return positions.get(loc);
	}

	private void registerVoter(String sessionid, String name) {
		try {
			voters = (Map) cache.find(VOTERS_FQN);
			if (voters == null)
				voters = new HashMap<String, String>();
			voters.put(sessionid, name);
			cache.attach(VOTERS_FQN, voters);
		} catch (CacheException e) {
			log.error("Error getting cache:", e);
		}
	}
}
