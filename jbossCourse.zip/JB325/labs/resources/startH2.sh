#/bin/sh

java -cp h2*.jar -Dh2.bindAddress=localhost org.h2.tools.Server -tcpAllowOthers