package gov.doe.us.monitor;

import org.jboss.system.ServiceMBean;

public interface JvmMemoryPoolServiceMBean extends ServiceMBean {

	public long getCodeCachePeakInit();

	public long getCodeCachePeakUsed();

	public long getCodeCachePeakCommitted();

	public long getCodeCachePeakMax();

	public long getCodeCacheCurrentInit();

	public long getCodeCacheCurrentUsed();

	public long getCodeCacheCurrentCommitted();

	public long getCodeCacheCurrentMax();

	public long getEdenSpacePeakInit();

	public long getEdenSpacePeakUsed();

	public long getEdenSpacePeakCommitted();

	public long getEdenSpacePeakMax();

	public long getEdenSpaceCurrentInit();

	public long getEdenSpaceCurrentUsed();

	public long getEdenSpaceCurrentCommitted();

	public long getEdenSpaceCurrentMax();

	public long getSurvivorSpacePeakInit();

	public long getSurvivorSpacePeakUsed();

	public long getSurvivorSpacePeakCommitted();

	public long getSurvivorSpacePeakMax();

	public long getSurvivorSpaceCurrentInit();

	public long getSurvivorSpaceCurrentUsed();

	public long getSurvivorSpaceCurrentCommitted();

	public long getSurvivorSpaceCurrentMax();

	public long getTenuredGenPeakInit();

	public long getTenuredGenPeakUsed();

	public long getTenuredGenPeakCommitted();

	public long getTenuredGenPeakMax();

	public long getTenuredGenCurrentInit();

	public long getTenuredGenCurrentUsed();

	public long getTenuredGenCurrentCommitted();

	public long getTenuredGenCurrentMax();

	public long getPermGenPeakInit();

	public long getPermGenPeakUsed();

	public long getPermGenPeakCommitted();

	public long getPermGenPeakMax();

	public long getPermGenCurrentInit();

	public long getPermGenCurrentUsed();

	public long getPermGenCurrentCommitted();

	public long getPermGenCurrentMax();

}
