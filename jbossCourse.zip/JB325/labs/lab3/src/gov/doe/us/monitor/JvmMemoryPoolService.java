package gov.doe.us.monitor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;

import org.jboss.system.ServiceMBeanSupport;


/**
 * 
 * @author dnorwood
 *
 */
public class JvmMemoryPoolService extends ServiceMBeanSupport {

	private static final String PEAK = "peak";
	private static final String USED = "used";
	private static final String MAX = "max";
	private static final String INIT = "init";
	private static final String CURRENT = "current";
	private static final String COMMITTED = "committed";
	Map<String, Map<String, Map<String, Long>>> numbers = new HashMap<String, Map<String, Map<String, Long>>>();

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getCodeCacheCurrentCommitted()
	 */
	public long getCodeCacheCurrentCommitted() {
		parsePoolInfo();
		return getNumber("code cache", CURRENT, COMMITTED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getCodeCacheCurrentInit()
	 */
	public long getCodeCacheCurrentInit() {
		parsePoolInfo();
		return getNumber("code cache", CURRENT, INIT);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getCodeCacheCurrentMax()
	 */
	public long getCodeCacheCurrentMax() {
		parsePoolInfo();
		return getNumber("code cache", CURRENT, MAX);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getCodeCacheCurrentUsed()
	 */
	public long getCodeCacheCurrentUsed() {
		parsePoolInfo();
		return getNumber("code cache", CURRENT, USED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getCodeCachePeakCommitted()
	 */
	public long getCodeCachePeakCommitted() {
		parsePoolInfo();
		return getNumber("code cache", PEAK, COMMITTED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getCodeCachePeakInit()
	 */
	public long getCodeCachePeakInit() {
		parsePoolInfo();
		return getNumber("code cache", PEAK, INIT);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getCodeCachePeakMax()
	 */
	public long getCodeCachePeakMax() {
		parsePoolInfo();
		return getNumber("code cache", PEAK, MAX);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getCodeCachePeakUsed()
	 */
	public long getCodeCachePeakUsed() {
		parsePoolInfo();
		return getNumber("code cache", PEAK, USED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getEdenSpaceCurrentCommitted()
	 */
	public long getEdenSpaceCurrentCommitted() {
		parsePoolInfo();
		return getNumber("eden space", CURRENT, COMMITTED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getEdenSpaceCurrentInit()
	 */
	public long getEdenSpaceCurrentInit() {
		parsePoolInfo();
		return getNumber("eden space", CURRENT, INIT);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getEdenSpaceCurrentMax()
	 */
	public long getEdenSpaceCurrentMax() {
		parsePoolInfo();
		return getNumber("eden space", CURRENT, MAX);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getEdenSpaceCurrentUsed()
	 */
	public long getEdenSpaceCurrentUsed() {
		parsePoolInfo();
		return getNumber("eden space", CURRENT, USED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getEdenSpacePeakCommitted()
	 */
	public long getEdenSpacePeakCommitted() {
		parsePoolInfo();
		return getNumber("eden space", PEAK, COMMITTED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getEdenSpacePeakInit()
	 */
	public long getEdenSpacePeakInit() {
		parsePoolInfo();
		return getNumber("eden space", PEAK, INIT);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getEdenSpacePeakMax()
	 */
	public long getEdenSpacePeakMax() {
		parsePoolInfo();
		return getNumber("eden space", PEAK, MAX);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getEdenSpacePeakUsed()
	 */
	public long getEdenSpacePeakUsed() {
		parsePoolInfo();
		return getNumber("eden space", PEAK, USED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getName()
	 */
	@Override
	public String getName() {
		parsePoolInfo();
		return "Monitor:service=JvmMemoryPoolService";
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getPermGenCurrentCommitted()
	 */
	public long getPermGenCurrentCommitted() {
		parsePoolInfo();
		return getNumber("perm gen", CURRENT, COMMITTED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getPermGenCurrentInit()
	 */
	public long getPermGenCurrentInit() {
		parsePoolInfo();
		return getNumber("perm gen", CURRENT, INIT);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getPermGenCurrentMax()
	 */
	public long getPermGenCurrentMax() {
		parsePoolInfo();
		return getNumber("perm gen", CURRENT, MAX);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getPermGenCurrentUsed()
	 */
	public long getPermGenCurrentUsed() {
		parsePoolInfo();
		return getNumber("perm gen", CURRENT, USED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getPermGenPeakCommitted()
	 */
	public long getPermGenPeakCommitted() {
		parsePoolInfo();
		return getNumber("perm gen", PEAK, COMMITTED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getPermGenPeakInit()
	 */
	public long getPermGenPeakInit() {
		parsePoolInfo();
		return getNumber("perm gen", PEAK, INIT);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getPermGenPeakMax()
	 */
	public long getPermGenPeakMax() {
		parsePoolInfo();
		return getNumber("perm gen", PEAK, MAX);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getPermGenPeakUsed()
	 */
	public long getPermGenPeakUsed() {
		parsePoolInfo();
		return getNumber("perm gen", PEAK, USED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getSurvivorSpaceCurrentCommitted()
	 */
	public long getSurvivorSpaceCurrentCommitted() {
		parsePoolInfo();
		return getNumber("survivor space", CURRENT, COMMITTED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getSurvivorSpaceCurrentInit()
	 */
	public long getSurvivorSpaceCurrentInit() {
		parsePoolInfo();
		return getNumber("survivor space", CURRENT, INIT);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getSurvivorSpaceCurrentMax()
	 */
	public long getSurvivorSpaceCurrentMax() {
		parsePoolInfo();
		return getNumber("survivor space", CURRENT, MAX);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getSurvivorSpaceCurrentUsed()
	 */
	public long getSurvivorSpaceCurrentUsed() {
		parsePoolInfo();
		return getNumber("survivor space", CURRENT, USED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getSurvivorSpacePeakCommitted()
	 */
	public long getSurvivorSpacePeakCommitted() {
		parsePoolInfo();
		return getNumber("survivor space", PEAK, COMMITTED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getSurvivorSpacePeakInit()
	 */
	public long getSurvivorSpacePeakInit() {
		parsePoolInfo();
		return getNumber("survivor space", PEAK, INIT);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getSurvivorSpacePeakMax()
	 */
	public long getSurvivorSpacePeakMax() {
		parsePoolInfo();
		return getNumber("survivor space", PEAK, MAX);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getSurvivorSpacePeakUsed()
	 */
	public long getSurvivorSpacePeakUsed() {
		parsePoolInfo();
		return getNumber("survivor space", PEAK, USED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getTenuredGenCurrentCommitted()
	 */
	public long getTenuredGenCurrentCommitted() {
		parsePoolInfo();
		return getNumber("tenured gen", CURRENT, COMMITTED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getTenuredGenCurrentInit()
	 */
	public long getTenuredGenCurrentInit() {
		parsePoolInfo();
		return getNumber("tenured gen", CURRENT, INIT);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getTenuredGenCurrentMax()
	 */
	public long getTenuredGenCurrentMax() {
		parsePoolInfo();
		return getNumber("tenured gen", CURRENT, MAX);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getTenuredGenCurrentUsed()
	 */
	public long getTenuredGenCurrentUsed() {
		parsePoolInfo();
		return getNumber("tenured gen", CURRENT, USED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getTenuredGenPeakCommitted()
	 */
	public long getTenuredGenPeakCommitted() {
		parsePoolInfo();
		return getNumber("tenured gen", PEAK, COMMITTED);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getTenuredGenPeakInit()
	 */
	public long getTenuredGenPeakInit() {
		parsePoolInfo();
		return getNumber("tenured gen", PEAK, INIT);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getTenuredGenPeakMax()
	 */
	public long getTenuredGenPeakMax() {
		parsePoolInfo();
		return getNumber("tenured gen", PEAK, MAX);
	}

	/* (non-Javadoc)
	 * @see gov.doe.us.monitor.test#getTenuredGenPeakUsed()
	 */
	public long getTenuredGenPeakUsed() {
		parsePoolInfo();
		return getNumber("tenured gen", PEAK, USED);
	}

	private void addNumber(String numberAsString, String poolName,
			String peakOrCurrent, String kind) {

		Long l = Long.valueOf(Long.parseLong(numberAsString));
		Map<String, Map<String, Long>> poolMap = numbers.get(poolName
				.toLowerCase());
		if (poolMap == null) {
			poolMap = new HashMap<String, Map<String, Long>>();
			numbers.put(poolName.toLowerCase(), poolMap);
		}
		Map<String, Long> peakCurrentMap = poolMap.get(peakOrCurrent
				.toLowerCase());
		if (peakCurrentMap == null) {
			peakCurrentMap = new HashMap<String, Long>();
			poolMap.put(peakOrCurrent.toLowerCase(), peakCurrentMap);
		}
		peakCurrentMap.put(kind.toLowerCase(), l);

	}

	@SuppressWarnings("unchecked")
	private String getMemoryPoolDump() {
		ObjectName o = null;
		try {
			o = new ObjectName("jboss.system:type=ServerInfo");
		} catch (MalformedObjectNameException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			e.printStackTrace();
		}

		List srvrList = MBeanServerFactory.findMBeanServer(null);
		MBeanServer server = (MBeanServer) srvrList.iterator().next();
		String s = null;
		try {
			s = (String) server.invoke(o, "listMemoryPools",
					new Object[] { Boolean.FALSE }, new String[] { "boolean" });
		} catch (InstanceNotFoundException e) {
			e.printStackTrace();
		} catch (MBeanException e) {
			e.printStackTrace();
		} catch (ReflectionException e) {
			e.printStackTrace();
		}

		return s;
	}

	private long getNumber(String poolName, String peakOrCurrent, String kind) {
		Map<String, Map<String, Long>> poolMap = numbers.get(poolName);
		if (poolMap == null) {
			return 0;
		}
		Map<String, Long> peakCurrentMap = poolMap.get(peakOrCurrent);
		if (peakCurrentMap == null) {
			return 0;
		}
		Long l = peakCurrentMap.get(kind);
		return l.longValue();
	}

	private void parsePoolInfo() {
		String memoryPoolDump = getMemoryPoolDump();
		String[] pieces = memoryPoolDump.split("[\\:\\,\\>\\<\\(\\)]");
		resetAll();
		int i = 0;
		String poolName = null;
		String peakOrCurrent = null;
		while (i < pieces.length) {
			String s1 = pieces[i++].trim();
			if (s1.length() == 0) {
				continue;
			}
			if ("Pool".equals(s1.trim())) {
				String pn = pieces[i++].trim();
				poolName = pn.toLowerCase();
				continue;
			}
			if ("Peak Usage".equals(s1.trim())) {
				peakOrCurrent = PEAK;
				continue;
			}
			if ("Current Usage".equals(s1.trim())) {
				peakOrCurrent = CURRENT;
				continue;
			}
			if (INIT.equals(s1.trim())) {
				addNumber(pieces[i++], poolName, peakOrCurrent, INIT);
				continue;
			}
			if (USED.equals(s1.trim())) {
				addNumber(pieces[i++], poolName, peakOrCurrent, USED);
				continue;
			}
			if (COMMITTED.equals(s1.trim())) {
				addNumber(pieces[i++], poolName, peakOrCurrent, COMMITTED);
				continue;
			}
			if (MAX.equals(s1.trim())) {
				addNumber(pieces[i++], poolName, peakOrCurrent, MAX);
				continue;
			}

		}

	}

	private void resetAll() {
		numbers = new HashMap<String, Map<String, Map<String, Long>>>();
	}

}
