package gov.doe.us.monitor;

import org.jboss.system.ServiceMBean;

/**
 * The management interface of the JBossMonitorMBean
 * 
 * @version $Revision: 2389 $
 */
public interface JBossMonitorMBean extends ServiceMBean {

	// FIXME: add accessors for the interval attribute
	public void setInterval(int interval);
	public int getInterval();
	
	// Set the interval between checks of VM memory and threads

	// Get the interval between checks of VM memory and threads


	// Set the history buffer length
	public void setHistoryLength(int length);

	// Set the history buffer length
	public int getHistoryLength();

	// Get a monitor history report
	public String history();

}
