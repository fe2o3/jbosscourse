package gov.doe.us.monitor;

import java.util.LinkedList;
import javax.management.Notification;

import org.jboss.logging.Logger;
import org.jboss.system.ServiceMBeanSupport;

/**
 * The lab1 advanced solution
 * 
 * @author Scott.Stark@jboss.org
 * @version $Revision: 522 $
 */
public class JBossMonitor extends ServiceMBeanSupport implements
		JBossMonitorMBean, Runnable {

	private Logger log = Logger.getLogger(JBossMonitor.class.getName());

	private Thread monitor = null;
	private int interval = 1000;
	private int historyLength = 10;
	private int count = 0;
	private LinkedList<String> history = new LinkedList<String>();

	public JBossMonitor() {
	}

	public String getName() {
		return "JBossMonitor";
	}

	protected void startService() throws Exception {

		super.log = Logger.getLogger(super.getServiceName().toString());

		// FIXME: Create a new thread with this monitor and name it "JBossMonitor"
		monitor=new Thread(this,getName());
		//monitor.setName(getName());

		// FIXME: Set it as a daemon
		monitor.setDaemon(true);

		// FIXME: start the thread
		monitor.start();

	}

	protected void stopService() {
		// FIXME: stop this by interrupting the monitor thread
		monitor.interrupt();
	}

	// FIXME: implement 2 attribute accessors from MBean interface
	public int getInterval() {
		return interval;
	}

	public void setInterval(int interval) {
		this.interval = interval;
	}

	// Set the history buffer length
	public void setHistoryLength(int length) {
		log.debug("Updating historyLength: " + length);
		this.historyLength = length;
		if (historyLength < 0)
			historyLength = 0;
		while (historyLength < history.size())
			history.removeFirst();
	}

	

	// Set the history buffer length
	public int getHistoryLength() {
		return this.historyLength;
	}

	// Get a monitor history report
	public String history() {
		StringBuffer report = new StringBuffer("<h1>JBossMonitor History</h1>\n");
		report.append("<pre>\n");
		for (int r = 0; r < history.size(); r++)
			report.append(history.get(r));
		report.append("</pre>\n");
		return report.toString();
	}

	public void run() {

		boolean running = true;

		while (running) {
			try {
				Thread.currentThread();
				// FIXME: put the current thread to sleep for the interval you added
				// Hint: consider using a static Thread method for the current running thread
				Thread.sleep(getInterval());
				
				count++;
				long now = System.currentTimeMillis();
				// Send a notification
				Notification msg = new Notification("monitor.IntervalElapsed",
						this, count, now);
				super.sendNotification(msg);

				// Log the memory usage
				String mem = getMem();
				 log.info(mem);
				// Log the thread usage
				String threads = getThreads();
				log.info(getThreads());
				StringBuffer record = new StringBuffer("JBossMonitor #" + count
						+ ", CurrentTimeMillis: ");
				record.append(now);
				record.append('\n');
				record.append(mem);
				record.append('\n');
				record.append(threads);
				record.append('\n');
				history.add(record.toString());
				if (history.size() > historyLength)
					history.removeFirst();
			} catch (Exception e) {
				running = false;
			}
		}
	}

	private String getMem() {
		return "Total Mem: " + Runtime.getRuntime().totalMemory() + "  "
				+ "Free Mem:  " + Runtime.getRuntime().freeMemory();
	}

	private String getThreads() {
		ThreadGroup root = null;
		root = Thread.currentThread().getThreadGroup();

		while (root.getParent() != null)
			root = root.getParent();

		return "Thread Count: " + root.activeCount();
	}

}
