package com.ebikes.ejb;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Stateless EJB for running the Transactions lab in JB325 class.
 * 
 * @author <a href="mailto:dnorwood@redhat.com">David Norwood</a>
 * @version <tt>$Revision: 1 $</tt>
 */
@Stateless
// @Stateless(mappedName=AccountDataBean.JNDI_NAME)
@TransactionManagement(TransactionManagementType.CONTAINER)
public class AccountDataBean implements AccountDataLocal 
{
	@Resource(name="sessionContext")
	SessionContext sessionContext;

	private static Log log = LogFactory.getLog(AccountDataBean.class);

	public static final String JNDI_NAME = "lab7/AccountDataBean/local";
	private final static String DS1_NAME = "java:XAAccountDS1";
	private final static String DS2_NAME = "java:XAAccountDS2";
	private final static String QUEUE_NAME = "queue/lab7Queue";

	private Connection connection_1;
	private Connection connection_2;

	private int ACCOUNT_ID = 123;
	private int ORDER_ID = 999;

	/**
	 * 
	 */
	public void RESETDBS() {
		log.info("[lab-trans]: " + "Resetting database: in AccountDataBean.RESETDBS().");
		initDS();
	}

	/**
	 * Perform updates to tables in the database. If the boolean is true,
	 * also perform a JMS publish to a Queue, which may or may not exist.
	 * 
	 */
	public void performXATransactions(boolean sendNotice) 
		throws Exception {
		log.info("[lab-trans]: "
				+ "Entering AccountDataBean.performXATransactions()...");
		try {
			connectDS();
			log.info("Now attempting updates to tables in database ...");
			PreparedStatement ps;
			String sql = "insert into ORD (ID,ODATE,CUSTOMER) values ("
				+ ORDER_ID + ",CURRENT_DATE(),1)";
			ps = this.connection_1.prepareStatement(sql);
			ps.executeUpdate();
			sql = "insert into LINEITEM (OID,LINEID,PRODUCT,QTY) values ("
				+ ORDER_ID + ",1,1,100)";
			ps = this.connection_1.prepareStatement(sql);
			ps.executeUpdate();
			sql = "insert into ACCOUNT (ID, BALANCE, CUSTOMERID) values ("
				+ ACCOUNT_ID + ",10000.00,1)";
			ps = this.connection_1.prepareStatement(sql);
			ps.executeUpdate();

			if (sendNotice)
				sendJMS();
		} catch (SQLException e) {
			log.error("[lab-trans]: "
				+ "AccountDataBean.performXATransactions() - ", e);
			throw new Exception(e);
		} catch (Exception e) {
			this.sessionContext.setRollbackOnly();
			log.error("[lab-trans]: "
				+ "AccountDataBean.performXATransactions() - Marked for rollback.", e);
			throw new Exception(e);
		} finally {
			disconnectDS();
		}
	}

	/**
	 * Get the BALANCE column from the passed database indicated. Allows for 
	 * two connections, which isn't used in this lab currently.
	 * 
	 */
	public double balance(int db) {
		double b = -1;
		try {
			connectDS();
			switch (db) {
			case 1:
				b = _balance(this.connection_1);
				break;
			case 2:
				b = _balance(this.connection_2);
				break;
			default:
				break;
			}
			disconnectDS();
			log.info("Balance for connection " + db + ":" + b);
			return b;
		} catch (Exception e) {
			log.error("Error getting balance from connection " + db + ":", e);
			disconnectDS();
		}
		return b;
	}

	/**
	 * Get the balance from the ACCOUNT table.
	 * 
	 * @param c a {@link Connection} object
	 * @return a double value from the column
	 * 
	 * @throws NamingException
	 * @throws SQLException
	 */
	private double _balance(Connection c) throws NamingException, SQLException {
		String st = "select BALANCE from ACCOUNT where ID = ?";
		PreparedStatement ps = c.prepareStatement(st);
		ps.setInt(1, ACCOUNT_ID); // set earlier when setting up the lab
		ResultSet rs = ps.executeQuery();
		rs.beforeFirst();

		double r = 0.0;
		if (rs.next()) {
			r = rs.getDouble(1);
			ps.close();
			disconnectDS();
		} else {
			ps.close();
			disconnectDS();
			//throw new EJBException("Balance not found.");
		}
		return r;
	}

	/**
	 * Connect to the database(s). Currently only one connection is
	 * to be used.
	 * 
	 * @throws NamingException
	 * @throws SQLException
	 */
	private void connectDS() throws NamingException, SQLException {
		log.info("[lab-trans]: " + "Entering AccountDataBean.connectDS()...");
		InitialContext ic = new InitialContext();
		DataSource ds1 = (DataSource) ic.lookup(DS1_NAME);
		DataSource ds2 = (DataSource) ic.lookup(DS2_NAME);
		if (this.connection_1 == null || this.connection_1.isClosed())
			this.connection_1 = ds1.getConnection();
		log.debug("[lab-trans]: " + DS1_NAME + " connected.");
		if (this.connection_2 == null || this.connection_2.isClosed())
			this.connection_2 = ds2.getConnection();
		log.debug("[lab-trans]: " + DS2_NAME + " connected.");
	}

	/**
	 * 
	 */
	private void disconnectDS() {
		log.info("Closing connections ...");
		try {
			if (!this.connection_1.isClosed())
				this.connection_1.close();
			if (!this.connection_2.isClosed())
				this.connection_2.close();
		} catch (Exception e) {
			// simply ignore
		}
	}

	/**
	 * Connect & initialize the database.
	 * 
	 */
	private void initDS() {
		log.info("Initializing database ...");
		try {
			connectDS();

			PreparedStatement ps;
			String sql = "delete from ACCOUNT where ID > 0";
			ps = connection_1.prepareStatement(sql);
			ps.execute();
			sql = "delete from LINEITEM where OID > 0";
			ps = connection_1.prepareStatement(sql);
			ps.execute();
			sql = "delete from ORD where ID > 0";
			ps = connection_1.prepareStatement(sql);
			ps.execute();

			log.info("Data cleaned from the database.");
			ps.close();
		} catch (Exception e) {
			log.error("Error connecting to DB:", e);
		} finally {
			disconnectDS();
		}
	}

	/**
	 * Send a JMS transaction to an existing queue. If queue doesn't exist, this
	 * should fail and trigger a database rollback.
	 * 
	 * @throws Exception
	 */
	private void sendJMS() throws Exception {

		InitialContext ic = null;

		javax.jms.Connection jms0 = null;
		javax.jms.Connection jms1 = null;

		ConnectionFactory cf = null;

		// connect to the first node
		try {
			ic = new InitialContext();

			cf = (ConnectionFactory) ic.lookup("/ConnectionFactory");
			Queue distributedQueue = (Queue) ic.lookup(QUEUE_NAME);
			log.info("Queue " + distributedQueue.getQueueName() + " exists");

			// ... so this is a connection to a cluster node
			jms0 = cf.createConnection();
			// ... and this is a connection to a different cluster node
			jms1 = cf.createConnection();

			// Create a session, and a producer on the first connection

			Session session0 = jms0.createSession(false,
					Session.AUTO_ACKNOWLEDGE);
			MessageProducer publisher0 = session0
					.createProducer(distributedQueue);

			// Create another session, and consumer on the second connection

/*			Session session1 = jms1.createSession(false,
					Session.AUTO_ACKNOWLEDGE);
			MessageConsumer consumer1 = session1
					.createConsumer(distributedQueue);
			ExampleListener messageListener1 = new ExampleListener(
					"MessageListener1");
			consumer1.setMessageListener(messageListener1);
*/
			// Start connections, so we can receive the message
			jms0.start();
			jms1.start();

			// Send a message
			TextMessage message = session0.createTextMessage("Hello! This is your test message!");
			publisher0.send(message);

			log.info("The message was successfully sent to the queue");

/*			messageListener1.waitForMessage(3000);
			message = (TextMessage) messageListener1.getMessage();
			log(messageListener1.getName() + " received message: "
					+ message.getText());
*/
			//displayProviderInfo(connection0.getMetaData());
		} finally {
			if (ic != null) {
				try {
					ic.close();
				} catch (Exception e) {
					throw e;
				}
			}

			try {
				if (jms0 != null) {
					jms0.close();
				}
			} catch (JMSException e) {
				log.error("Could not close connection " + jms0
						+ ", exception was " + e);
				throw e;
			}

			try {
				if (jms1 != null) {
					jms1.close();
				}
			} catch (JMSException e) {
				log.error("Could not close connection " + jms1
						+ ", exception was " + e);
				throw e;
			}

		}
	}
}
