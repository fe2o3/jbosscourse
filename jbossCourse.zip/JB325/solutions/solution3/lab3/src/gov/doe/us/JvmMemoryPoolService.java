package gov.doe.us.monitor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;

import org.jboss.system.ServiceMBeanSupport;


public class JvmMemoryPoolService extends ServiceMBeanSupport implements
		JvmMemoryPoolServiceMBean {

	private static final String PEAK = "peak";
	private static final String USED = "used";
	private static final String MAX = "max";
	private static final String INIT = "init";
	private static final String CURRENT = "current";
	private static final String COMMITTED = "committed";
	Map<String, Map<String, Map<String, Long>>> numbers = new HashMap<String, Map<String, Map<String, Long>>>();

	public long getCodeCacheCurrentCommitted() {
		parsePoolInfo();
		return getNumber("code cache", CURRENT, COMMITTED);
	}

	public long getCodeCacheCurrentInit() {
		parsePoolInfo();
		return getNumber("code cache", CURRENT, INIT);
	}

	public long getCodeCacheCurrentMax() {
		parsePoolInfo();
		return getNumber("code cache", CURRENT, MAX);
	}

	public long getCodeCacheCurrentUsed() {
		parsePoolInfo();
		return getNumber("code cache", CURRENT, USED);
	}

	public long getCodeCachePeakCommitted() {
		parsePoolInfo();
		return getNumber("code cache", PEAK, COMMITTED);
	}

	public long getCodeCachePeakInit() {
		parsePoolInfo();
		return getNumber("code cache", PEAK, INIT);
	}

	public long getCodeCachePeakMax() {
		parsePoolInfo();
		return getNumber("code cache", PEAK, MAX);
	}

	public long getCodeCachePeakUsed() {
		parsePoolInfo();
		return getNumber("code cache", PEAK, USED);
	}

	public long getEdenSpaceCurrentCommitted() {
		parsePoolInfo();
		return getNumber("eden space", CURRENT, COMMITTED);
	}

	public long getEdenSpaceCurrentInit() {
		parsePoolInfo();
		return getNumber("eden space", CURRENT, INIT);
	}

	public long getEdenSpaceCurrentMax() {
		parsePoolInfo();
		return getNumber("eden space", CURRENT, MAX);
	}

	public long getEdenSpaceCurrentUsed() {
		parsePoolInfo();
		return getNumber("eden space", CURRENT, USED);
	}

	public long getEdenSpacePeakCommitted() {
		parsePoolInfo();
		return getNumber("eden space", PEAK, COMMITTED);
	}

	public long getEdenSpacePeakInit() {
		parsePoolInfo();
		return getNumber("eden space", PEAK, INIT);
	}

	public long getEdenSpacePeakMax() {
		parsePoolInfo();
		return getNumber("eden space", PEAK, MAX);
	}

	public long getEdenSpacePeakUsed() {
		parsePoolInfo();
		return getNumber("eden space", PEAK, USED);
	}

	@Override
	public String getName() {
		parsePoolInfo();
		return "Monitor:service=JvmMemoryPoolService";
	}

	public long getPermGenCurrentCommitted() {
		parsePoolInfo();
		return getNumber("perm gen", CURRENT, COMMITTED);
	}

	public long getPermGenCurrentInit() {
		parsePoolInfo();
		return getNumber("perm gen", CURRENT, INIT);
	}

	public long getPermGenCurrentMax() {
		parsePoolInfo();
		return getNumber("perm gen", CURRENT, MAX);
	}

	public long getPermGenCurrentUsed() {
		parsePoolInfo();
		return getNumber("perm gen", CURRENT, USED);
	}

	public long getPermGenPeakCommitted() {
		parsePoolInfo();
		return getNumber("perm gen", PEAK, COMMITTED);
	}

	public long getPermGenPeakInit() {
		parsePoolInfo();
		return getNumber("perm gen", PEAK, INIT);
	}

	public long getPermGenPeakMax() {
		parsePoolInfo();
		return getNumber("perm gen", PEAK, MAX);
	}

	public long getPermGenPeakUsed() {
		parsePoolInfo();
		return getNumber("perm gen", PEAK, USED);
	}

	public long getSurvivorSpaceCurrentCommitted() {
		parsePoolInfo();
		return getNumber("survivor space", CURRENT, COMMITTED);
	}

	public long getSurvivorSpaceCurrentInit() {
		parsePoolInfo();
		return getNumber("survivor space", CURRENT, INIT);
	}

	public long getSurvivorSpaceCurrentMax() {
		parsePoolInfo();
		return getNumber("survivor space", CURRENT, MAX);
	}

	public long getSurvivorSpaceCurrentUsed() {
		parsePoolInfo();
		return getNumber("survivor space", CURRENT, USED);
	}

	public long getSurvivorSpacePeakCommitted() {
		parsePoolInfo();
		return getNumber("survivor space", PEAK, COMMITTED);
	}

	public long getSurvivorSpacePeakInit() {
		parsePoolInfo();
		return getNumber("survivor space", PEAK, INIT);
	}

	public long getSurvivorSpacePeakMax() {
		parsePoolInfo();
		return getNumber("survivor space", PEAK, MAX);
	}

	public long getSurvivorSpacePeakUsed() {
		parsePoolInfo();
		return getNumber("survivor space", PEAK, USED);
	}

	public long getTenuredGenCurrentCommitted() {
		parsePoolInfo();
		return getNumber("tenured gen", CURRENT, COMMITTED);
	}

	public long getTenuredGenCurrentInit() {
		parsePoolInfo();
		return getNumber("tenured gen", CURRENT, INIT);
	}

	public long getTenuredGenCurrentMax() {
		parsePoolInfo();
		return getNumber("tenured gen", CURRENT, MAX);
	}

	public long getTenuredGenCurrentUsed() {
		parsePoolInfo();
		return getNumber("tenured gen", CURRENT, USED);
	}

	public long getTenuredGenPeakCommitted() {
		parsePoolInfo();
		return getNumber("tenured gen", PEAK, COMMITTED);
	}

	public long getTenuredGenPeakInit() {
		parsePoolInfo();
		return getNumber("tenured gen", PEAK, INIT);
	}

	public long getTenuredGenPeakMax() {
		parsePoolInfo();
		return getNumber("tenured gen", PEAK, MAX);
	}

	public long getTenuredGenPeakUsed() {
		parsePoolInfo();
		return getNumber("tenured gen", PEAK, USED);
	}

	private void addNumber(String numberAsString, String poolName,
			String peakOrCurrent, String kind) {

		Long l = Long.valueOf(Long.parseLong(numberAsString));
		Map<String, Map<String, Long>> poolMap = numbers.get(poolName
				.toLowerCase());
		if (poolMap == null) {
			poolMap = new HashMap<String, Map<String, Long>>();
			numbers.put(poolName.toLowerCase(), poolMap);
		}
		Map<String, Long> peakCurrentMap = poolMap.get(peakOrCurrent
				.toLowerCase());
		if (peakCurrentMap == null) {
			peakCurrentMap = new HashMap<String, Long>();
			poolMap.put(peakOrCurrent.toLowerCase(), peakCurrentMap);
		}
		peakCurrentMap.put(kind.toLowerCase(), l);

	}

	@SuppressWarnings("unchecked")
	private String getMemoryPoolDump() {
		ObjectName o = null;
		try {
			o = new ObjectName("jboss.system:type=ServerInfo");
		} catch (MalformedObjectNameException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			e.printStackTrace();
		}

		List srvrList = MBeanServerFactory.findMBeanServer(null);
		MBeanServer server = (MBeanServer) srvrList.iterator().next();
		String s = null;
		try {
			s = (String) server.invoke(o, "listMemoryPools",
					new Object[] { Boolean.FALSE }, new String[] { "boolean" });
		} catch (InstanceNotFoundException e) {
			e.printStackTrace();
		} catch (MBeanException e) {
			e.printStackTrace();
		} catch (ReflectionException e) {
			e.printStackTrace();
		}

		return s;
	}

	private long getNumber(String poolName, String peakOrCurrent, String kind) {
		Map<String, Map<String, Long>> poolMap = numbers.get(poolName);
		if (poolMap == null) {
			return 0;
		}
		Map<String, Long> peakCurrentMap = poolMap.get(peakOrCurrent);
		if (peakCurrentMap == null) {
			return 0;
		}
		Long l = peakCurrentMap.get(kind);
		return l.longValue();
	}

	private void parsePoolInfo() {
		String memoryPoolDump = getMemoryPoolDump();
		String[] pieces = memoryPoolDump.split("[\\:\\,\\>\\<\\(\\)]");
		resetAll();
		int i = 0;
		String poolName = null;
		String peakOrCurrent = null;
		while (i < pieces.length) {
			String s1 = pieces[i++].trim();
			if (s1.length() == 0) {
				continue;
			}
			if ("Pool".equals(s1.trim())) {
				String pn = pieces[i++].trim();
				poolName = pn.toLowerCase();
				continue;
			}
			if ("Peak Usage".equals(s1.trim())) {
				peakOrCurrent = PEAK;
				continue;
			}
			if ("Current Usage".equals(s1.trim())) {
				peakOrCurrent = CURRENT;
				continue;
			}
			if (INIT.equals(s1.trim())) {
				addNumber(pieces[i++], poolName, peakOrCurrent, INIT);
				continue;
			}
			if (USED.equals(s1.trim())) {
				addNumber(pieces[i++], poolName, peakOrCurrent, USED);
				continue;
			}
			if (COMMITTED.equals(s1.trim())) {
				addNumber(pieces[i++], poolName, peakOrCurrent, COMMITTED);
				continue;
			}
			if (MAX.equals(s1.trim())) {
				addNumber(pieces[i++], poolName, peakOrCurrent, MAX);
				continue;
			}

		}

	}

	private void resetAll() {
		numbers = new HashMap<String, Map<String, Map<String, Long>>>();
	}

}
