package gov.doe.us.monitor;

import org.jboss.system.ServiceMBean;

/**
 * The management interface of the JBossMonitorMBean
 * 
 * @version $Revision: 2389 $
 */
public interface JBossMonitorMBean extends ServiceMBean {

	// Set the interval in milliseconds between checks of VM memory and threas
	public void setInterval(int interval);

	// Get the interval in milliseconds between checks of VM memory and threas
	public int getInterval();

	// Set the history buffer length
	public void setHistoryLength(int length);

	// Set the history buffer length
	public int getHistoryLength();

	// Get a monitor history report
	public String history();

}
