package gov.doe.us.monitor.client;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.naming.InitialContext;

import org.jboss.security.SecurityAssociation;
import org.jboss.security.SimplePrincipal;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * A JMX JUnit test client that access the Monitor:name=JBossMonitor MBean
 * through an RMI adaptor. adapted from Scott Stark
 * 
 * @author David Norwood <mailto:dnorwood@redhat.com>
 * 
 */
public class RMITest {

	private static MBeanServerConnection server;

	//FIXME: Make sure this matches what appears in the JMX console.
	private static final String JMX_BEAN_NAME = "Monitor:name=JBossMonitor,type=XMBean"; 

	/**
	 * @throws java.lang.Exception		server.invoke(monitorName, "stopService", params, signature);

	 */
	@Before
	public void setUp() throws Exception {
		String connectorName = "jmx/invoker/RMIAdaptor"; // FIXME: Complete this line.
		InitialContext ctx = new InitialContext();
		System.out.println(ctx.getEnvironment().toString());
		server = (MBeanServerConnection) ctx.lookup(connectorName); // FIXME: Complete this line.
		SecurityAssociation.setPrincipal(new SimplePrincipal("admin")); // FIXME: Enter the correct credentials.
		SecurityAssociation.setCredential("admin"); // FIXME: Enter the correct credentials.
	}

	@Test
	public void testRMI() throws Exception {
		// Invoke the history operation via the RMIAdaptor/MBeanServer
		Object[] params = {};
		String[] signature = {};
		ObjectName monitorName = new ObjectName(JMX_BEAN_NAME);
		String history = (String) server.invoke(monitorName, "history", params,
				signature);
		System.out.println("Invoked JBossMonitor.history:");
		System.out.println(history);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

}
