package gov.electoral.nz.aop;

import gov.electoral.nz.Ballot;
import gov.electoral.nz.OfficeBallot;
import gov.electoral.nz.ejb.VotingBooth;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/*
 * JBoss, Home of Professional Open Source.
 * Copyright 2009, Red Hat Middleware LLC, and individual contributors
 * as indicated by the @author tags. See the copyright.txt file in the
 * distribution for a full listing of individual contributors. 
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

public class VoteLogger {

	private static Log log = LogFactory.getLog(VoteLogger.class);

	@AroundInvoke
	public Object invoke(InvocationContext ctx) throws Exception {
		VotingBooth booth = (VotingBooth) ctx.getTarget();
		Ballot ballot = booth.getBallot();
		OfficeBallot vote = (OfficeBallot) ballot.officeList.get(0);
		log.debug("Vote cast for " + vote.officeName);
		try {
			return ctx.proceed();
		} finally {
			log.debug("Complete.");
		}
	}

}
